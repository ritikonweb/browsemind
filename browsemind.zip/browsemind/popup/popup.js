/**
 * BrowseMind — Popup Controller
 * Manages all popup UI interactions: tabs, search, recent, digest.
 */

document.addEventListener('DOMContentLoaded', init);

// ── State ──
let currentTab = 'search';
let recentOffset = 0;
const RECENT_LIMIT = 20;
let digestDate = new Date();
let deleteTimeouts = {};

// ── Helpers ──
function timeAgo(timestamp) {
    const seconds = Math.floor((Date.now() - timestamp) / 1000);
    if (seconds < 60) return 'just now';
    if (seconds < 3600) { const m = Math.floor(seconds / 60); return `${m} ${m === 1 ? 'min' : 'mins'} ago`; }
    if (seconds < 86400) { const h = Math.floor(seconds / 3600); return `${h} ${h === 1 ? 'hour' : 'hours'} ago`; }
    if (seconds < 604800) { const d = Math.floor(seconds / 86400); return `${d} ${d === 1 ? 'day' : 'days'} ago`; }
    const w = Math.floor(seconds / 604800);
    return `${w} ${w === 1 ? 'week' : 'weeks'} ago`;
}

function readingTime(wc) {
    if (!wc) return '';
    const m = Math.ceil(wc / 200);
    return m < 1 ? '< 1 min read' : `${m} min read`;
}

function formatDuration(seconds) {
    if (!seconds || seconds < 60) return '< 1 min';
    if (seconds < 3600) { const m = Math.floor(seconds / 60); return `${m} ${m === 1 ? 'min' : 'mins'}`; }
    return `${(seconds / 3600).toFixed(1)} hours`;
}

function escapeHtml(text) {
    if (!text) return '';
    const d = document.createElement('div');
    d.appendChild(document.createTextNode(text));
    return d.innerHTML;
}

function truncate(text, max = 100) {
    if (!text) return '';
    return text.length <= max ? text : text.substring(0, max).trim() + '...';
}

function todayStr() { return new Date().toISOString().split('T')[0]; }
function yesterdayStr() { const d = new Date(); d.setDate(d.getDate() - 1); return d.toISOString().split('T')[0]; }

function formatDateNice(dateStr) {
    const date = new Date(dateStr + 'T00:00:00');
    return date.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
}

function faviconUrl(domain) {
    return domain ? `https://www.google.com/s2/favicons?domain=${domain}&sz=32` : '';
}

function sendMessage(msg) {
    return new Promise((resolve) => {
        try {
            chrome.runtime.sendMessage(msg, (response) => {
                if (chrome.runtime.lastError) {
                    console.warn('[BrowseMind Popup] sendMessage error:', chrome.runtime.lastError.message);
                    resolve({});
                    return;
                }
                resolve(response || {});
            });
        } catch (err) {
            console.warn('[BrowseMind Popup] sendMessage exception:', err);
            resolve({});
        }
    });
}

// ── Initialization ──
async function init() {
    try {
        // Save the current page immediately (save-on-exit: popup open = snapshot)
        await sendMessage({ action: 'popupOpened' });

        // Check onboarding
        const data = await chrome.storage.local.get('bm_onboarding_done');
        if (!data.bm_onboarding_done) {
            showOnboarding();
            return;
        }

        // Check if paused
        const pauseResp = await sendMessage({ action: 'getSetting', key: 'paused' });
        if (pauseResp && pauseResp.value) {
            const pi = document.getElementById('pauseIndicator');
            if (pi) pi.style.display = 'inline';
        }

        setupTabs();
        setupSearch();
        setupDigest();
        setupSettings();

        // Check if has any pages
        const countResp = await sendMessage({ action: 'getPageCount' });
        if (!countResp.count || countResp.count === 0) {
            switchTab('recent');
        } else {
            switchTab('search');
        }
    } catch (err) {
        console.error('[BrowseMind Popup] init error:', err);
        // Still set up tabs even if background fails
        setupTabs();
        setupSearch();
        setupDigest();
        setupSettings();
        switchTab('recent');
    }
}

// ── Onboarding ──
function showOnboarding() {
    document.getElementById('onboarding').style.display = 'block';
    document.querySelectorAll('.tab-content').forEach(el => el.style.display = 'none');

    document.getElementById('onboardingDismiss').addEventListener('click', async () => {
        await chrome.storage.local.set({ bm_onboarding_done: true });
        document.getElementById('onboarding').style.display = 'none';
        setupTabs();
        setupSearch();
        setupDigest();
        setupSettings();
        switchTab('recent');
    });
}

// ── Tab switching ──
function setupTabs() {
    document.querySelectorAll('.tab').forEach(tab => {
        tab.addEventListener('click', () => {
            switchTab(tab.dataset.tab);
        });
    });
}

function switchTab(tabName) {
    currentTab = tabName;

    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));

    document.querySelector(`.tab[data-tab="${tabName}"]`).classList.add('active');
    document.getElementById(`tab-${tabName}`).classList.add('active');

    if (tabName === 'recent') loadRecent();
    if (tabName === 'search') document.getElementById('searchInput').focus();
    if (tabName === 'digest') loadDigest();
}

// ══════════════════════════════════════
// SEARCH TAB
// ══════════════════════════════════════

let searchDebounce = null;

function setupSearch() {
    const input = document.getElementById('searchInput');
    const clearBtn = document.getElementById('searchClear');

    input.addEventListener('input', () => {
        const val = input.value.trim();
        clearBtn.style.display = val ? 'block' : 'none';

        if (searchDebounce) clearTimeout(searchDebounce);

        if (!val) {
            document.getElementById('searchResults').innerHTML = '';
            document.getElementById('aiSearchSection').style.display = 'none';
            checkSearchEmpty();
            return;
        }

        searchDebounce = setTimeout(() => doLocalSearch(val), 300);
    });

    input.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
            const val = input.value.trim();
            if (val) doLocalSearch(val);
        }
    });

    clearBtn.addEventListener('click', () => {
        input.value = '';
        clearBtn.style.display = 'none';
        document.getElementById('searchResults').innerHTML = '';
        document.getElementById('aiSearchSection').style.display = 'none';
        checkSearchEmpty();
        input.focus();
    });

    document.getElementById('aiSearchBtn').addEventListener('click', doAISearch);
}

async function doLocalSearch(query) {
    const resp = await sendMessage({ action: 'searchLocal', query, limit: 15 });
    const results = resp.results || [];

    renderSearchResults(results, false);

    // Show AI search button if few results
    const aiSection = document.getElementById('aiSearchSection');
    if (results.length < 3 && query.length >= 3) {
        aiSection.style.display = 'block';
    } else if (results.length > 0) {
        aiSection.style.display = 'block';
    } else {
        aiSection.style.display = 'none';
    }

    document.getElementById('searchEmpty').style.display = results.length === 0 ? 'none' : 'none';
    if (results.length === 0) {
        document.getElementById('searchResults').innerHTML = `
      <div class="search-no-results">
        🔍 No results found for "${escapeHtml(query)}"<br>
        <span style="font-size:10px;color:var(--text-muted)">Try different keywords or use AI Search</span>
      </div>`;
        aiSection.style.display = 'block';
    }
}

async function doAISearch() {
    const query = document.getElementById('searchInput').value.trim();
    if (!query) return;

    const btn = document.getElementById('aiSearchBtn');
    btn.textContent = '🤖 AI searching...';
    btn.disabled = true;

    try {
        // Get local results first for context
        const localResp = await sendMessage({ action: 'searchLocal', query, limit: 50 });
        const localResults = localResp.results || [];

        const resp = await sendMessage({
            action: 'searchAI',
            query,
            localResults
        });

        if (resp.error) {
            btn.textContent = resp.error;
            setTimeout(() => {
                btn.textContent = '🤖 Search with AI for better results';
                btn.disabled = false;
            }, 3000);
            return;
        }

        if (resp.results) {
            renderSearchResults(resp.results, true);
            if (resp.interpretation) {
                const interp = document.createElement('div');
                interp.className = 'search-no-results';
                interp.style.color = 'var(--accent-light)';
                interp.style.fontSize = '10px';
                interp.textContent = `🤖 ${resp.interpretation}`;
                document.getElementById('searchResults').prepend(interp);
            }
        }
    } catch (err) {
        btn.textContent = 'AI search unavailable right now.';
    }

    setTimeout(() => {
        btn.textContent = '🤖 Search with AI for better results';
        btn.disabled = false;
    }, 2000);
}

function renderSearchResults(results, isAI) {
    const container = document.getElementById('searchResults');
    container.innerHTML = '';

    results.forEach((page, i) => {
        container.appendChild(createPageCard(page, isAI, i));
    });
}

async function checkSearchEmpty() {
    const countResp = await sendMessage({ action: 'getPageCount' });
    const empty = document.getElementById('searchEmpty');
    empty.style.display = (!countResp.count || countResp.count === 0) ? 'block' : 'none';
}

// ══════════════════════════════════════
// RECENT TAB
// ══════════════════════════════════════

async function loadRecent() {
    // Load stats
    const stats = await sendMessage({ action: 'getTodayStats' });
    document.getElementById('statPages').textContent = `📄 ${stats.pagesVisited || 0} pages today`;
    document.getElementById('statTime').textContent = `⏱️ ${formatDuration(stats.totalTimeSpent || 0)}`;
    document.getElementById('statDomains').textContent = `🌐 ${stats.uniqueDomains || 0} sites`;

    // Load recent pages
    recentOffset = 0;
    const resp = await sendMessage({ action: 'getRecentPages', limit: RECENT_LIMIT, offset: 0 });
    const pages = resp.pages || [];

    const list = document.getElementById('recentList');
    list.innerHTML = '';

    if (pages.length === 0) {
        document.getElementById('recentEmpty').style.display = 'block';
        document.getElementById('loadMoreWrap').style.display = 'none';
        return;
    }

    document.getElementById('recentEmpty').style.display = 'none';
    renderRecentPages(pages, list);

    // Load more button
    document.getElementById('loadMoreWrap').style.display = pages.length >= RECENT_LIMIT ? 'block' : 'none';
    document.getElementById('loadMoreBtn').onclick = async () => {
        recentOffset += RECENT_LIMIT;
        const moreResp = await sendMessage({ action: 'getRecentPages', limit: RECENT_LIMIT, offset: recentOffset });
        const morePages = moreResp.pages || [];
        renderRecentPages(morePages, list);
        document.getElementById('loadMoreWrap').style.display = morePages.length >= RECENT_LIMIT ? 'block' : 'none';
    };
}

function renderRecentPages(pages, container) {
    const today = todayStr();
    const yesterday = yesterdayStr();
    let lastGroup = null;

    pages.forEach((page, i) => {
        const pageDate = page.date || new Date(page.timestamp).toISOString().split('T')[0];
        let group;

        if (pageDate === today) group = 'Today';
        else if (pageDate === yesterday) group = 'Yesterday';
        else {
            const daysAgo = Math.floor((Date.now() - page.timestamp) / 86400000);
            group = daysAgo <= 7 ? 'Earlier This Week' : 'Older';
        }

        if (group !== lastGroup) {
            const label = document.createElement('div');
            label.className = 'date-group-label';
            label.textContent = group;
            container.appendChild(label);
            lastGroup = group;
        }

        container.appendChild(createPageCard(page, false, i, true));
    });
}

// ══════════════════════════════════════
// DIGEST TAB
// ══════════════════════════════════════

function setupDigest() {
    document.getElementById('digestPrev').addEventListener('click', () => {
        digestDate.setDate(digestDate.getDate() - 1);
        loadDigest();
    });

    document.getElementById('digestNext').addEventListener('click', () => {
        const tomorrow = new Date();
        tomorrow.setDate(tomorrow.getDate() + 1);
        if (digestDate < tomorrow) {
            digestDate.setDate(digestDate.getDate() + 1);
            loadDigest();
        }
    });

    document.getElementById('digestGenerateBtn').addEventListener('click', generateDigestUI);

    document.getElementById('openFullView').addEventListener('click', (e) => {
        e.preventDefault();
        chrome.tabs.create({ url: chrome.runtime.getURL('fullpage/fullpage.html') });
    });
}

async function loadDigest() {
    const dateStr = digestDate.toISOString().split('T')[0];
    const today = todayStr();

    // Update date label
    if (dateStr === today) {
        document.getElementById('digestDateLabel').textContent = 'Today — ' + formatDateNice(dateStr);
    } else {
        document.getElementById('digestDateLabel').textContent = formatDateNice(dateStr);
    }

    // Disable next button if at today
    document.getElementById('digestNext').disabled = (dateStr >= today);

    // Hide all sections
    document.getElementById('digestContent').style.display = 'none';
    document.getElementById('digestGenerate').style.display = 'none';
    document.getElementById('digestLoading').style.display = 'none';
    document.getElementById('digestError').style.display = 'none';
    document.getElementById('fullViewLink').style.display = 'none';

    // Check page count for this date
    const pagesResp = await sendMessage({ action: 'getPagesByDate', date: dateStr });
    const pageCount = pagesResp.pages ? pagesResp.pages.length : 0;

    if (pageCount < 5) {
        document.getElementById('digestError').style.display = 'block';
        document.getElementById('digestError').textContent = pageCount === 0
            ? 'No browsing data for this day.'
            : 'Not enough browsing data for this day to generate a meaningful digest. Browse more and check back!';
        return;
    }

    // Show generate button
    document.getElementById('digestGenerate').style.display = 'block';
}

async function generateDigestUI() {
    const dateStr = digestDate.toISOString().split('T')[0];

    document.getElementById('digestGenerate').style.display = 'none';
    document.getElementById('digestLoading').style.display = 'block';

    const resp = await sendMessage({ action: 'generateDigest', date: dateStr });

    document.getElementById('digestLoading').style.display = 'none';

    if (resp.error) {
        document.getElementById('digestError').style.display = 'block';
        document.getElementById('digestError').textContent = resp.error;
        document.getElementById('digestGenerate').style.display = 'block';
        return;
    }

    if (resp.digest) {
        renderDigest(resp.digest);
    }
}

function renderDigest(digest) {
    const container = document.getElementById('digestContent');
    container.style.display = 'block';
    container.innerHTML = '';

    // Stats row
    const statsSection = document.createElement('div');
    statsSection.className = 'digest-section';
    statsSection.innerHTML = `
    <div class="digest-stats-row">
      <span>📄 ${digest.totalPages || '?'} pages</span>
      <span>⏱️ ${digest.totalTime || '?'}</span>
      <span>🌐 ${digest.topSites ? digest.topSites.length : '?'} sites</span>
    </div>`;
    container.appendChild(statsSection);

    // Topics
    if (digest.topTopics && digest.topTopics.length > 0) {
        const topicsSection = document.createElement('div');
        topicsSection.className = 'digest-section';
        const emojis = ['💻', '🤖', '🛒', '📰', '🍳', '🎮', '📚', '🎵', '💼', '🔬'];
        topicsSection.innerHTML = `
      <div class="digest-label">🏷️ Top Topics</div>
      <div class="topic-pills">
        ${digest.topTopics.map((t, i) => `<span class="topic-pill">${emojis[i] || '📌'} ${escapeHtml(t)}</span>`).join('')}
      </div>`;
        container.appendChild(topicsSection);
    }

    // Top sites bars
    if (digest.topSites && digest.topSites.length > 0) {
        const maxVisits = Math.max(...digest.topSites.map(s => s.visits));
        const sitesSection = document.createElement('div');
        sitesSection.className = 'digest-section';
        sitesSection.innerHTML = `
      <div class="digest-label">🌐 Top Sites</div>
      ${digest.topSites.map(s => `
        <div class="domain-bar-row">
          <span class="domain-bar-label">${s.emoji || '🌐'} ${escapeHtml(s.domain)}</span>
          <div class="domain-bar-track">
            <div class="domain-bar-fill" style="width:${(s.visits / maxVisits) * 100}%"></div>
          </div>
          <span class="domain-bar-count">${s.visits}</span>
        </div>`).join('')}`;
        container.appendChild(sitesSection);
    }

    // Highlight
    if (digest.highlight) {
        const hlSection = document.createElement('div');
        hlSection.className = 'digest-section';
        hlSection.innerHTML = `
      <div class="digest-label">⭐ Highlight</div>
      <div class="digest-highlight">${escapeHtml(digest.highlight)}</div>`;
        container.appendChild(hlSection);
    }

    // Insight
    if (digest.insight) {
        const insSection = document.createElement('div');
        insSection.className = 'digest-section';
        insSection.innerHTML = `
      <div class="digest-label">💡 Insight</div>
      <div class="digest-insight">${escapeHtml(digest.insight)}</div>`;
        container.appendChild(insSection);
    }

    // Fun fact
    if (digest.funFact) {
        const funSection = document.createElement('div');
        funSection.className = 'digest-section';
        funSection.innerHTML = `
      <div class="digest-label">🎲 Fun Fact</div>
      <div class="digest-funfact">${escapeHtml(digest.funFact)}</div>`;
        container.appendChild(funSection);
    }

    // Productivity
    if (digest.productivity) {
        const prodSection = document.createElement('div');
        prodSection.className = 'digest-section';
        const workPercent = parseInt(digest.productivity) || 50;
        prodSection.innerHTML = `
      <div class="digest-label">📈 Productivity</div>
      <div class="productivity-label">${workPercent}% work · ${100 - workPercent}% personal</div>
      <div class="productivity-bar">
        <div class="productivity-work" style="width:${workPercent}%"></div>
        <div class="productivity-personal"></div>
      </div>`;
        container.appendChild(prodSection);
    }

    document.getElementById('fullViewLink').style.display = 'block';
}

// ══════════════════════════════════════
// PAGE CARD BUILDER
// ══════════════════════════════════════

function createPageCard(page, isAI, index, showDelete = false) {
    const card = document.createElement('div');
    card.className = 'page-card';
    card.style.animationDelay = `${index * 50}ms`;

    const fav = faviconUrl(page.domain);
    const meta = [
        escapeHtml(page.domain),
        timeAgo(page.timestamp),
        readingTime(page.wordCount)
    ].filter(Boolean).join(' <span class="meta-separator">·</span> ');

    let actionsHtml = '';
    if (showDelete) {
        actionsHtml += `<button class="card-action-btn delete" data-id="${page.id}" title="Delete">🗑️</button>`;
    }
    actionsHtml += `<button class="card-action-btn open" data-url="${escapeHtml(page.url)}" title="Open">🔗</button>`;

    card.innerHTML = `
    <div class="card-header">
      <img class="card-favicon" src="${fav}" alt="" onerror="this.style.display='none';this.nextElementSibling.style.display='inline'">
      <span class="card-favicon-fallback" style="display:none">🌐</span>
      <span class="card-title">${escapeHtml(page.title || 'Untitled')}</span>
      ${isAI ? '<span class="ai-badge">🤖 AI match</span>' : ''}
    </div>
    <div class="card-meta">${meta}</div>
    <div class="card-preview">${escapeHtml(truncate(page.contentPreview || page.description, 120))}</div>
    <div class="card-actions">${actionsHtml}</div>`;

    // Click card → open page
    card.addEventListener('click', (e) => {
        if (e.target.closest('.card-action-btn')) return;
        chrome.tabs.create({ url: page.url });
    });

    // Open button
    card.querySelector('.card-action-btn.open')?.addEventListener('click', (e) => {
        e.stopPropagation();
        chrome.tabs.create({ url: page.url });
    });

    // Delete button
    const deleteBtn = card.querySelector('.card-action-btn.delete');
    if (deleteBtn) {
        deleteBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            deletePage(page.id, card);
        });
    }

    return card;
}

// ══════════════════════════════════════
// DELETE WITH UNDO
// ══════════════════════════════════════

function deletePage(pageId, cardEl) {
    // Hide card
    cardEl.style.opacity = '0';
    cardEl.style.transform = 'translateY(-10px)';
    cardEl.style.transition = 'all 0.2s';

    // Show toast
    const toast = document.getElementById('deleteToast');
    toast.style.display = 'flex';

    // Cancel previous timeout for this toast
    if (deleteTimeouts._toast) clearTimeout(deleteTimeouts._toast);

    // Store undo info
    toast._pageId = pageId;
    toast._cardEl = cardEl;

    // Auto-delete after 3 seconds
    deleteTimeouts._toast = setTimeout(async () => {
        toast.style.display = 'none';
        await sendMessage({ action: 'deletePage', id: pageId });
        cardEl.remove();
    }, 3000);

    // Undo button
    document.getElementById('toastUndo').onclick = () => {
        clearTimeout(deleteTimeouts._toast);
        toast.style.display = 'none';
        cardEl.style.opacity = '1';
        cardEl.style.transform = 'translateY(0)';
    };
}

// ══════════════════════════════════════
// SETTINGS BUTTON
// ══════════════════════════════════════

function setupSettings() {
    document.getElementById('settingsBtn').addEventListener('click', () => {
        chrome.tabs.create({ url: chrome.runtime.getURL('settings/settings.html') });
    });
}
