/**
 * BrowseMind — IndexedDB Wrapper
 * Handles all local data storage for page memories, stats, and settings.
 * Database: "BrowseMindDB" v1
 */

const DB_NAME = 'BrowseMindDB';
const DB_VERSION = 1;

let dbInstance = null;

/**
 * Open/initialize the IndexedDB database
 */
function openDB() {
  return new Promise((resolve, reject) => {
    if (dbInstance) {
      resolve(dbInstance);
      return;
    }

    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = (event) => {
      const db = event.target.result;

      // Pages store — all page memories
      if (!db.objectStoreNames.contains('pages')) {
        const pagesStore = db.createObjectStore('pages', { keyPath: 'id', autoIncrement: true });
        pagesStore.createIndex('url', 'url', { unique: false });
        pagesStore.createIndex('domain', 'domain', { unique: false });
        pagesStore.createIndex('timestamp', 'timestamp', { unique: false });
        pagesStore.createIndex('title', 'title', { unique: false });
        pagesStore.createIndex('date', 'date', { unique: false });
      }

      // Stats store — daily browsing statistics
      if (!db.objectStoreNames.contains('stats')) {
        db.createObjectStore('stats', { keyPath: 'date' });
      }

      // Settings store — user preferences
      if (!db.objectStoreNames.contains('settings')) {
        db.createObjectStore('settings', { keyPath: 'key' });
      }

      // Digest cache store — cached daily digests
      if (!db.objectStoreNames.contains('digestCache')) {
        db.createObjectStore('digestCache', { keyPath: 'date' });
      }
    };

    request.onsuccess = (event) => {
      dbInstance = event.target.result;

      // Handle connection closing unexpectedly
      dbInstance.onclose = () => { dbInstance = null; };
      dbInstance.onerror = (e) => { console.warn('BrowseMind DB error:', e); };

      resolve(dbInstance);
    };

    request.onerror = (event) => {
      console.error('BrowseMind: Failed to open database', event.target.error);
      reject(event.target.error);
    };
  });
}

/**
 * Save a page to the database. Handles deduplication (same URL within 6 hours → update timeSpent).
 */
async function savePage(pageData) {
  try {
    const db = await openDB();
    const now = Date.now();
    const today = new Date().toISOString().split('T')[0];
    const sixHoursAgo = now - (6 * 60 * 60 * 1000);

    // Build searchText for fast keyword search
    const searchText = [
      pageData.title || '',
      pageData.description || '',
      pageData.headings || '',
      pageData.contentPreview || '',
      pageData.domain || ''
    ].join(' ').toLowerCase();

    const record = {
      title: pageData.title || '',
      url: pageData.url || '',
      domain: pageData.domain || '',
      description: pageData.description || '',
      headings: pageData.headings || '',
      contentPreview: pageData.contentPreview || '',
      favicon: pageData.favicon || '',
      ogImage: pageData.ogImage || '',
      language: pageData.language || 'en',
      wordCount: pageData.wordCount || 0,
      timestamp: now,
      date: today,
      timeSpent: pageData.timeSpent || 30,
      searchText: searchText
    };

    // Check for duplicate URL within last 6 hours
    const tx = db.transaction('pages', 'readwrite');
    const store = tx.objectStore('pages');
    const urlIndex = store.index('url');
    const urlRequest = urlIndex.openCursor(IDBKeyRange.only(pageData.url));

    return new Promise((resolve, reject) => {
      let duplicateFound = false;

      urlRequest.onsuccess = (event) => {
        const cursor = event.target.result;
        if (cursor) {
          const existing = cursor.value;
          if (existing.timestamp > sixHoursAgo) {
            // Update timeSpent for existing entry
            existing.timeSpent = (existing.timeSpent || 0) + (pageData.timeSpent || 30);
            existing.timestamp = now; // refresh timestamp
            cursor.update(existing);
            duplicateFound = true;
            resolve({ updated: true, id: existing.id });
            return;
          }
          cursor.continue();
        } else {
          if (!duplicateFound) {
            // No duplicate — save new record
            const addRequest = store.add(record);
            addRequest.onsuccess = () => {
              resolve({ updated: false, id: addRequest.result });
            };
            addRequest.onerror = () => reject(addRequest.error);
          }
        }
      };

      urlRequest.onerror = () => reject(urlRequest.error);

      tx.oncomplete = () => {};
      tx.onerror = () => reject(tx.error);
    });
  } catch (err) {
    console.error('BrowseMind: savePage error', err);
    return null;
  }
}

/**
 * Get recent pages ordered by timestamp descending
 */
async function getRecentPages(limit = 20, offset = 0) {
  try {
    const db = await openDB();
    const tx = db.transaction('pages', 'readonly');
    const store = tx.objectStore('pages');
    const index = store.index('timestamp');

    return new Promise((resolve, reject) => {
      const results = [];
      let skipped = 0;

      const request = index.openCursor(null, 'prev');
      request.onsuccess = (event) => {
        const cursor = event.target.result;
        if (!cursor || results.length >= limit) {
          resolve(results);
          return;
        }
        if (skipped < offset) {
          skipped++;
          cursor.continue();
          return;
        }
        results.push(cursor.value);
        cursor.continue();
      };
      request.onerror = () => reject(request.error);
    });
  } catch (err) {
    console.error('BrowseMind: getRecentPages error', err);
    return [];
  }
}

/**
 * Search pages by keyword matching against searchText
 */
async function searchPages(query, limit = 20) {
  try {
    const db = await openDB();
    const keywords = query.toLowerCase().trim().split(/\s+/).filter(k => k.length > 1);

    if (keywords.length === 0) return [];

    const tx = db.transaction('pages', 'readonly');
    const store = tx.objectStore('pages');

    return new Promise((resolve, reject) => {
      const scored = [];
      const request = store.openCursor();

      request.onsuccess = (event) => {
        const cursor = event.target.result;
        if (!cursor) {
          scored.sort((a, b) => b.score - a.score);
          resolve(scored.slice(0, limit));
          return;
        }

        const record = cursor.value;
        let score = 0;

        for (const kw of keywords) {
          if ((record.title || '').toLowerCase().includes(kw)) score += 10;
          if ((record.domain || '').toLowerCase().includes(kw)) score += 8;
          if ((record.headings || '').toLowerCase().includes(kw)) score += 6;
          if ((record.description || '').toLowerCase().includes(kw)) score += 4;
          if ((record.contentPreview || '').toLowerCase().includes(kw)) score += 2;
        }

        if (score > 0) {
          // Recency bonus
          const daysSince = (Date.now() - record.timestamp) / 86400000;
          if (daysSince < 1) score += 5;
          else if (daysSince < 3) score += 3;
          else if (daysSince < 7) score += 1;

          // Time spent bonus
          if (record.timeSpent > 120) score += 3;
          else if (record.timeSpent > 60) score += 1;

          scored.push({ ...record, score });
        }

        cursor.continue();
      };

      request.onerror = () => reject(request.error);
    });
  } catch (err) {
    console.error('BrowseMind: searchPages error', err);
    return [];
  }
}

/**
 * Get all pages for a specific date string (YYYY-MM-DD)
 */
async function getPagesByDate(date) {
  try {
    const db = await openDB();
    const tx = db.transaction('pages', 'readonly');
    const store = tx.objectStore('pages');
    const index = store.index('date');

    return new Promise((resolve, reject) => {
      const results = [];
      const request = index.openCursor(IDBKeyRange.only(date));
      request.onsuccess = (event) => {
        const cursor = event.target.result;
        if (!cursor) {
          resolve(results);
          return;
        }
        results.push(cursor.value);
        cursor.continue();
      };
      request.onerror = () => reject(request.error);
    });
  } catch (err) {
    console.error('BrowseMind: getPagesByDate error', err);
    return [];
  }
}

/**
 * Get pages filtered by domain
 */
async function getPagesByDomain(domain, limit = 20) {
  try {
    const db = await openDB();
    const tx = db.transaction('pages', 'readonly');
    const store = tx.objectStore('pages');
    const index = store.index('domain');

    return new Promise((resolve, reject) => {
      const results = [];
      const request = index.openCursor(IDBKeyRange.only(domain));
      request.onsuccess = (event) => {
        const cursor = event.target.result;
        if (!cursor || results.length >= limit) {
          resolve(results);
          return;
        }
        results.push(cursor.value);
        cursor.continue();
      };
      request.onerror = () => reject(request.error);
    });
  } catch (err) {
    console.error('BrowseMind: getPagesByDomain error', err);
    return [];
  }
}

/**
 * Get today's browsing stats
 */
async function getTodayStats() {
  try {
    const today = new Date().toISOString().split('T')[0];
    const pages = await getPagesByDate(today);

    const domains = new Set();
    let totalTime = 0;

    for (const page of pages) {
      domains.add(page.domain);
      totalTime += (page.timeSpent || 0);
    }

    return {
      pagesVisited: pages.length,
      totalTimeSpent: totalTime,
      uniqueDomains: domains.size,
      date: today
    };
  } catch (err) {
    console.error('BrowseMind: getTodayStats error', err);
    return { pagesVisited: 0, totalTimeSpent: 0, uniqueDomains: 0, date: new Date().toISOString().split('T')[0] };
  }
}

/**
 * Get all-time statistics
 */
async function getAllTimeStats() {
  try {
    const db = await openDB();
    const tx = db.transaction('pages', 'readonly');
    const store = tx.objectStore('pages');

    return new Promise((resolve, reject) => {
      let totalPages = 0;
      let totalTime = 0;
      const domains = new Set();
      let earliest = Infinity;

      const request = store.openCursor();
      request.onsuccess = (event) => {
        const cursor = event.target.result;
        if (!cursor) {
          resolve({
            totalPages,
            totalTimeSpent: totalTime,
            uniqueDomains: domains.size,
            earliestDate: earliest === Infinity ? null : new Date(earliest).toISOString().split('T')[0],
            estimatedSizeMB: ((totalPages * 1.5) / 1024).toFixed(1)
          });
          return;
        }

        totalPages++;
        totalTime += (cursor.value.timeSpent || 0);
        domains.add(cursor.value.domain);
        if (cursor.value.timestamp < earliest) earliest = cursor.value.timestamp;
        cursor.continue();
      };
      request.onerror = () => reject(request.error);
    });
  } catch (err) {
    console.error('BrowseMind: getAllTimeStats error', err);
    return { totalPages: 0, totalTimeSpent: 0, uniqueDomains: 0, earliestDate: null, estimatedSizeMB: '0' };
  }
}

/**
 * Delete pages older than N days
 */
async function deleteOldPages(daysToKeep = 90) {
  try {
    const db = await openDB();
    const cutoff = Date.now() - (daysToKeep * 24 * 60 * 60 * 1000);
    const tx = db.transaction('pages', 'readwrite');
    const store = tx.objectStore('pages');
    const index = store.index('timestamp');

    return new Promise((resolve, reject) => {
      let deleted = 0;
      const range = IDBKeyRange.upperBound(cutoff);
      const request = index.openCursor(range);

      request.onsuccess = (event) => {
        const cursor = event.target.result;
        if (!cursor) {
          resolve(deleted);
          return;
        }
        cursor.delete();
        deleted++;
        cursor.continue();
      };
      request.onerror = () => reject(request.error);
    });
  } catch (err) {
    console.error('BrowseMind: deleteOldPages error', err);
    return 0;
  }
}

/**
 * Delete a single page by ID
 */
async function deletePage(id) {
  try {
    const db = await openDB();
    const tx = db.transaction('pages', 'readwrite');
    const store = tx.objectStore('pages');

    return new Promise((resolve, reject) => {
      const request = store.delete(id);
      request.onsuccess = () => resolve(true);
      request.onerror = () => reject(request.error);
    });
  } catch (err) {
    console.error('BrowseMind: deletePage error', err);
    return false;
  }
}

/**
 * Clear all data from all stores
 */
async function clearAllData() {
  try {
    const db = await openDB();
    const storeNames = ['pages', 'stats', 'settings', 'digestCache'];
    const tx = db.transaction(storeNames, 'readwrite');

    for (const name of storeNames) {
      tx.objectStore(name).clear();
    }

    return new Promise((resolve, reject) => {
      tx.oncomplete = () => resolve(true);
      tx.onerror = () => reject(tx.error);
    });
  } catch (err) {
    console.error('BrowseMind: clearAllData error', err);
    return false;
  }
}

/**
 * Export all pages as JSON
 */
async function exportData() {
  try {
    const db = await openDB();
    const tx = db.transaction('pages', 'readonly');
    const store = tx.objectStore('pages');

    return new Promise((resolve, reject) => {
      const request = store.getAll();
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  } catch (err) {
    console.error('BrowseMind: exportData error', err);
    return [];
  }
}

/**
 * Get estimated database size
 */
async function getDatabaseSize() {
  try {
    const allPages = await exportData();
    const jsonStr = JSON.stringify(allPages);
    const bytes = new Blob([jsonStr]).size;

    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  } catch (err) {
    return '0 B';
  }
}

/**
 * Get top domains in last N days
 */
async function getTopDomains(days = 7, limit = 10) {
  try {
    const db = await openDB();
    const cutoff = Date.now() - (days * 24 * 60 * 60 * 1000);
    const tx = db.transaction('pages', 'readonly');
    const store = tx.objectStore('pages');
    const index = store.index('timestamp');

    return new Promise((resolve, reject) => {
      const domainCounts = {};
      const range = IDBKeyRange.lowerBound(cutoff);
      const request = index.openCursor(range);

      request.onsuccess = (event) => {
        const cursor = event.target.result;
        if (!cursor) {
          const sorted = Object.entries(domainCounts)
            .map(([domain, count]) => ({ domain, count }))
            .sort((a, b) => b.count - a.count)
            .slice(0, limit);
          resolve(sorted);
          return;
        }
        const domain = cursor.value.domain;
        domainCounts[domain] = (domainCounts[domain] || 0) + 1;
        cursor.continue();
      };
      request.onerror = () => reject(request.error);
    });
  } catch (err) {
    console.error('BrowseMind: getTopDomains error', err);
    return [];
  }
}

/**
 * Get a page by ID
 */
async function getPageById(id) {
  try {
    const db = await openDB();
    const tx = db.transaction('pages', 'readonly');
    const store = tx.objectStore('pages');

    return new Promise((resolve, reject) => {
      const request = store.get(id);
      request.onsuccess = () => resolve(request.result || null);
      request.onerror = () => reject(request.error);
    });
  } catch (err) {
    console.error('BrowseMind: getPageById error', err);
    return null;
  }
}

/**
 * Get multiple pages by their IDs
 */
async function getPagesByIds(ids) {
  try {
    const results = [];
    for (const id of ids) {
      const page = await getPageById(id);
      if (page) results.push(page);
    }
    return results;
  } catch (err) {
    console.error('BrowseMind: getPagesByIds error', err);
    return [];
  }
}

/**
 * Save/update a setting
 */
async function saveSetting(key, value) {
  try {
    const db = await openDB();
    const tx = db.transaction('settings', 'readwrite');
    const store = tx.objectStore('settings');
    store.put({ key, value });

    return new Promise((resolve, reject) => {
      tx.oncomplete = () => resolve(true);
      tx.onerror = () => reject(tx.error);
    });
  } catch (err) {
    console.error('BrowseMind: saveSetting error', err);
    return false;
  }
}

/**
 * Get a setting by key
 */
async function getSetting(key) {
  try {
    const db = await openDB();
    const tx = db.transaction('settings', 'readonly');
    const store = tx.objectStore('settings');

    return new Promise((resolve, reject) => {
      const request = store.get(key);
      request.onsuccess = () => resolve(request.result ? request.result.value : null);
      request.onerror = () => reject(request.error);
    });
  } catch (err) {
    console.error('BrowseMind: getSetting error', err);
    return null;
  }
}

/**
 * Get all settings
 */
async function getAllSettings() {
  try {
    const db = await openDB();
    const tx = db.transaction('settings', 'readonly');
    const store = tx.objectStore('settings');

    return new Promise((resolve, reject) => {
      const request = store.getAll();
      request.onsuccess = () => {
        const settings = {};
        for (const item of request.result) {
          settings[item.key] = item.value;
        }
        resolve(settings);
      };
      request.onerror = () => reject(request.error);
    });
  } catch (err) {
    console.error('BrowseMind: getAllSettings error', err);
    return {};
  }
}

/**
 * Save a cached digest
 */
async function saveDigestCache(date, digestData) {
  try {
    const db = await openDB();
    const tx = db.transaction('digestCache', 'readwrite');
    const store = tx.objectStore('digestCache');
    store.put({ date, data: digestData, cachedAt: Date.now() });

    return new Promise((resolve, reject) => {
      tx.oncomplete = () => resolve(true);
      tx.onerror = () => reject(tx.error);
    });
  } catch (err) {
    console.error('BrowseMind: saveDigestCache error', err);
    return false;
  }
}

/**
 * Get a cached digest for a date
 */
async function getDigestCache(date) {
  try {
    const db = await openDB();
    const tx = db.transaction('digestCache', 'readonly');
    const store = tx.objectStore('digestCache');

    return new Promise((resolve, reject) => {
      const request = store.get(date);
      request.onsuccess = () => resolve(request.result ? request.result.data : null);
      request.onerror = () => reject(request.error);
    });
  } catch (err) {
    console.error('BrowseMind: getDigestCache error', err);
    return null;
  }
}

/**
 * Get total page count
 */
async function getPageCount() {
  try {
    const db = await openDB();
    const tx = db.transaction('pages', 'readonly');
    const store = tx.objectStore('pages');

    return new Promise((resolve, reject) => {
      const request = store.count();
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  } catch (err) {
    console.error('BrowseMind: getPageCount error', err);
    return 0;
  }
}

// Export all methods
export {
  openDB,
  savePage,
  getRecentPages,
  searchPages,
  getPagesByDate,
  getPagesByDomain,
  getTodayStats,
  getAllTimeStats,
  deleteOldPages,
  deletePage,
  clearAllData,
  exportData,
  getDatabaseSize,
  getTopDomains,
  getPageById,
  getPagesByIds,
  saveSetting,
  getSetting,
  getAllSettings,
  saveDigestCache,
  getDigestCache,
  getPageCount
};
