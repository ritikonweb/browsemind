/**
 * BrowseMind — Daily Digest Generator
 * Generates AI-powered daily browsing digests via Cloudflare Worker proxy.
 * Digests are cached permanently per day after first generation.
 */

const PROXY_URL = "https://dpd-proxy.ritik-yadav666888.workers.dev";

/**
 * Build a compact browsing summary for a day's pages
 */
function buildDigestData(pages) {
    if (!pages || pages.length === 0) return null;

    // Count domains
    const domainCounts = {};
    let totalTime = 0;

    for (const page of pages) {
        const d = page.domain || 'unknown';
        domainCounts[d] = (domainCounts[d] || 0) + 1;
        totalTime += (page.timeSpent || 0);
    }

    // Sort domains by count
    const sortedDomains = Object.entries(domainCounts)
        .sort((a, b) => b[1] - a[1]);

    const topDomains = sortedDomains.slice(0, 5)
        .map(([domain, count]) => `${domain} (${count})`)
        .join(', ');

    const otherCount = sortedDomains.slice(5).reduce((sum, [, c]) => sum + c, 0);
    const domainsStr = otherCount > 0 ? `${topDomains}, others (${otherCount})` : topDomains;

    // Reading time in hours
    const readingHours = (totalTime / 3600).toFixed(1);

    // Page titles
    const titles = pages.map(p => p.title || 'Untitled').join('\n');

    return `Pages visited: ${pages.length}
Domains: ${domainsStr}
Total reading time: ${readingHours} hours
Unique domains: ${Object.keys(domainCounts).length}
Page titles:
${titles}`;
}

/**
 * Generate a daily digest for a given date
 * @param {Array} pages - Pages for the day
 * @param {string} date - Date string (YYYY-MM-DD)
 * @returns {Promise<Object>} Digest data or error
 */
export async function generateDigest(pages, date) {
    try {
        if (!pages || pages.length < 5) {
            return {
                error: 'Not enough browsing data for this day to generate a meaningful digest. Browse more and check back!'
            };
        }

        const data = buildDigestData(pages);
        if (!data) {
            return { error: 'Could not build digest data.' };
        }

        // Validate data length
        if (data.length > 10000) {
            // Truncate page titles if too long
            const truncatedPages = pages.slice(0, 50);
            return generateDigest(truncatedPages, date);
        }

        // Call proxy
        const response = await fetch(PROXY_URL + '/digest', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                action: 'digest',
                data: data
            })
        });

        if (!response.ok) {
            if (response.status === 429) {
                return { error: 'AI is busy right now. Please try again in a few minutes!' };
            }
            return { error: "Couldn't generate digest right now. Try again later!" };
        }

        const result = await response.json();
        return result;

    } catch (err) {
        console.error('BrowseMind: digest generation error', err);
        return { error: "Couldn't generate digest right now. Try again later!" };
    }
}
