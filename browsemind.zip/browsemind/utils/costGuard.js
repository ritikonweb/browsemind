/**
 * BrowseMind — Cost Guard
 * Tracks daily AI API usage (search + digest) to enforce limits.
 * Daily limit: 20 AI calls per day.
 * Uses chrome.storage.local for persistence.
 */

const DAILY_LIMIT = 20;
const STORAGE_PREFIX = 'bm_daily_';

/**
 * Get today's date key
 */
function getTodayKey() {
    const today = new Date().toISOString().split('T')[0];
    return STORAGE_PREFIX + today;
}

/**
 * Check if AI can be used (daily limit not reached)
 */
export async function canUseAI() {
    try {
        const key = getTodayKey();
        const result = await chrome.storage.local.get(key);
        const used = result[key] || 0;
        return used < DAILY_LIMIT;
    } catch (err) {
        console.error('BrowseMind: canUseAI error', err);
        return false;
    }
}

/**
 * Record an AI call (increment daily counter)
 */
export async function recordAICall() {
    try {
        const key = getTodayKey();
        const result = await chrome.storage.local.get(key);
        const used = (result[key] || 0) + 1;
        await chrome.storage.local.set({ [key]: used });
        return used;
    } catch (err) {
        console.error('BrowseMind: recordAICall error', err);
        return -1;
    }
}

/**
 * Get current usage stats
 */
export async function getUsage() {
    try {
        const key = getTodayKey();
        const result = await chrome.storage.local.get(key);
        const used = result[key] || 0;
        return {
            used,
            limit: DAILY_LIMIT,
            remaining: Math.max(0, DAILY_LIMIT - used),
            percentage: Math.round((used / DAILY_LIMIT) * 100)
        };
    } catch (err) {
        console.error('BrowseMind: getUsage error', err);
        return { used: 0, limit: DAILY_LIMIT, remaining: DAILY_LIMIT, percentage: 0 };
    }
}

/**
 * Clean up old daily keys (keep last 7 days)
 */
export async function cleanupOldKeys() {
    try {
        const all = await chrome.storage.local.get(null);
        const keysToRemove = [];
        const sevenDaysAgo = new Date();
        sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);

        for (const key of Object.keys(all)) {
            if (key.startsWith(STORAGE_PREFIX)) {
                const dateStr = key.replace(STORAGE_PREFIX, '');
                const date = new Date(dateStr);
                if (date < sevenDaysAgo) {
                    keysToRemove.push(key);
                }
            }
        }

        if (keysToRemove.length > 0) {
            await chrome.storage.local.remove(keysToRemove);
        }
    } catch (err) {
        console.error('BrowseMind: cleanupOldKeys error', err);
    }
}
