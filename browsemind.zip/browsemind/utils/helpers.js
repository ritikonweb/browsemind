/**
 * BrowseMind — Utility Helpers
 * Common utility functions used across the extension.
 */

/**
 * URLs to skip — never extract content from these
 */
const SKIP_PREFIXES = [
    'chrome://',
    'chrome-extension://',
    'edge://',
    'about:',
    'moz-extension://',
    'devtools://',
    'chrome://newtab',
    'chrome://extensions',
    'chrome://settings',
    'brave://',
    'opera://',
    'vivaldi://'
];

const SKIP_DOMAINS = [
    'chrome.google.com'
];

/**
 * Check if a URL should be skipped
 */
export function shouldSkipUrl(url) {
    if (!url) return true;

    for (const prefix of SKIP_PREFIXES) {
        if (url.startsWith(prefix)) return true;
    }

    try {
        const urlObj = new URL(url);
        for (const domain of SKIP_DOMAINS) {
            if (urlObj.hostname === domain || urlObj.hostname.endsWith('.' + domain)) return true;
        }
    } catch (e) {
        return true; // Invalid URL
    }

    return false;
}

/**
 * Format relative time (e.g., "2 hours ago", "just now", "3 days ago")
 */
export function timeAgo(timestamp) {
    const seconds = Math.floor((Date.now() - timestamp) / 1000);

    if (seconds < 60) return 'just now';
    if (seconds < 3600) {
        const mins = Math.floor(seconds / 60);
        return `${mins} ${mins === 1 ? 'min' : 'mins'} ago`;
    }
    if (seconds < 86400) {
        const hours = Math.floor(seconds / 3600);
        return `${hours} ${hours === 1 ? 'hour' : 'hours'} ago`;
    }
    if (seconds < 604800) {
        const days = Math.floor(seconds / 86400);
        return `${days} ${days === 1 ? 'day' : 'days'} ago`;
    }
    if (seconds < 2592000) {
        const weeks = Math.floor(seconds / 604800);
        return `${weeks} ${weeks === 1 ? 'week' : 'weeks'} ago`;
    }
    const months = Math.floor(seconds / 2592000);
    return `${months} ${months === 1 ? 'month' : 'months'} ago`;
}

/**
 * Estimate reading time from word count
 */
export function readingTime(wordCount) {
    if (!wordCount || wordCount < 1) return '';
    const mins = Math.ceil(wordCount / 200); // Average 200 wpm
    if (mins < 1) return '< 1 min read';
    return `${mins} min read`;
}

/**
 * Format seconds into human readable time
 */
export function formatDuration(seconds) {
    if (!seconds || seconds < 60) return '< 1 min';
    if (seconds < 3600) {
        const mins = Math.floor(seconds / 60);
        return `${mins} ${mins === 1 ? 'min' : 'mins'}`;
    }
    const hours = (seconds / 3600).toFixed(1);
    return `${hours} ${parseFloat(hours) === 1.0 ? 'hour' : 'hours'}`;
}

/**
 * Format a date string nicely
 */
export function formatDate(dateStr) {
    const date = new Date(dateStr + 'T00:00:00');
    const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
    return date.toLocaleDateString('en-US', options);
}

/**
 * Get today's date string (YYYY-MM-DD)
 */
export function getTodayDateString() {
    return new Date().toISOString().split('T')[0];
}

/**
 * Get yesterday's date string (YYYY-MM-DD)
 */
export function getYesterdayDateString() {
    const d = new Date();
    d.setDate(d.getDate() - 1);
    return d.toISOString().split('T')[0];
}

/**
 * Truncate text with ellipsis
 */
export function truncate(text, maxLen = 100) {
    if (!text) return '';
    if (text.length <= maxLen) return text;
    return text.substring(0, maxLen).trim() + '...';
}

/**
 * Clean and normalize text
 */
export function cleanText(text) {
    if (!text) return '';
    return text
        .replace(/\s+/g, ' ')
        .replace(/\n+/g, ' ')
        .trim();
}

/**
 * Debounce function
 */
export function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

/**
 * Simple hash function for cache keys
 */
export function simpleHash(str) {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
        const char = str.charCodeAt(i);
        hash = ((hash << 5) - hash) + char;
        hash = hash & hash; // Convert to 32bit integer
    }
    return 'bm_' + Math.abs(hash).toString(36);
}

/**
 * Group pages by date category
 */
export function groupPagesByDate(pages) {
    const today = getTodayDateString();
    const yesterday = getYesterdayDateString();

    const groups = {
        today: [],
        yesterday: [],
        thisWeek: [],
        older: []
    };

    const now = new Date();
    const weekAgo = new Date(now);
    weekAgo.setDate(weekAgo.getDate() - 7);
    const weekAgoStr = weekAgo.toISOString().split('T')[0];

    for (const page of pages) {
        const pageDate = page.date || new Date(page.timestamp).toISOString().split('T')[0];
        if (pageDate === today) {
            groups.today.push(page);
        } else if (pageDate === yesterday) {
            groups.yesterday.push(page);
        } else if (pageDate >= weekAgoStr) {
            groups.thisWeek.push(page);
        } else {
            groups.older.push(page);
        }
    }

    return groups;
}

/**
 * Safely parse JSON with fallback
 */
export function safeJsonParse(str, fallback = null) {
    try {
        return JSON.parse(str);
    } catch (e) {
        return fallback;
    }
}

/**
 * Get favicon URL with fallback
 */
export function getFaviconUrl(domain) {
    if (!domain) return '';
    return `https://www.google.com/s2/favicons?domain=${domain}&sz=32`;
}

/**
 * Escape HTML to prevent XSS
 */
export function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.appendChild(document.createTextNode(text));
    return div.innerHTML;
}
