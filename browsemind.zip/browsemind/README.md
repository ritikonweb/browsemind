# 🧠 BrowseMind — Your Second Brain for Browsing

**Never forget what you read online.**

## ✨ Features

- 🧠 **Auto-Remember** — Silently saves every page you spend time on. Zero manual effort.
- 🔍 **Natural Language Search** — Find anything with queries like "that cooking recipe from last week"
- 📊 **Daily Digest** — AI-generated summary of your browsing day with topics, insights, and fun stats
- 🔒 **100% Private** — All data stored locally in your browser. Nothing leaves your device.
- ⚡ **Instant Local Search** — Keyword search through thousands of pages in milliseconds
- 🤖 **AI-Powered** — Natural language understanding for when keywords aren't enough
- 🆓 **Completely Free** — No subscription, no premium tier, no ads. Free forever.

## 🔍 How It Works

1. **Install & Forget** — BrowseMind works silently in the background
2. **Browse Normally** — Every page you spend 30+ seconds on is remembered
3. **Search Anytime** — Click the extension and search in your own words
4. **Get Insights** — Generate daily digests of your browsing patterns

## 🔒 Privacy First

- ✅ All data stored locally in your browser (IndexedDB)
- ✅ No data sent to any server (saving is 100% local)
- ✅ AI search sends only your query + page titles (no content)
- ✅ No tracking, no analytics, no cookies
- ✅ Blocklist feature to exclude sensitive sites
- ✅ Full data export and deletion anytime

## 📦 Installation

1. Download/clone this repository
2. Open Chrome → `chrome://extensions`
3. Enable **"Developer Mode"** (top right toggle)
4. Click **"Load Unpacked"** → select the `browsemind` folder
5. Start browsing! BrowseMind remembers automatically.

## 🏗️ Architecture

```
browsemind/
├── manifest.json              # Chrome Extension Manifest V3
├── popup/                     # Extension popup (Search, Recent, Digest)
├── content/extractor.js       # Content extraction (runs in page)
├── background/background.js   # Service worker (tab tracking, orchestration)
├── db/database.js             # IndexedDB wrapper (all local storage)
├── search/                    # Local + AI-powered search
├── digest/                    # Daily digest generator
├── utils/                     # Helpers + cost guard
├── fullpage/                  # Full-page expanded view
├── settings/                  # User preferences
├── cloudflare-worker/         # AI proxy (Gemini via Cloudflare)
└── assets/                    # Extension icons
```

## 🛠️ Tech Stack

- **Vanilla JavaScript** — No frameworks, no build tools
- **Chrome Manifest V3** — Modern extension architecture
- **IndexedDB** — Local storage for 100,000+ pages
- **Gemini 2.0 Flash** — AI search + digest via Cloudflare Worker proxy
- **Cloudflare Workers** — Secure API proxy (free tier)

## 💰 Cost

- **Saving pages**: $0 (zero API calls — 100% local)
- **AI Search**: ~$0.0001 per search (0.01 cents)
- **Daily Digest**: ~$0.00015 per generation
- **Per user**: ~$0.02/month

## 👨‍💻 Built By

**[Ritik](https://www.ritik.co.in)** — Made with 🧠 to help you remember everything.

## 📄 License

MIT
