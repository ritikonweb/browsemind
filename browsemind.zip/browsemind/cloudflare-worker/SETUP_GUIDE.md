# 🚀 Cloudflare Worker Setup for BrowseMind

## Already Deployed

The worker is already deployed at: **`dpd-proxy.ritik-yadav666888.workers.dev`**

## Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/search` | POST | AI-powered browsing history search |
| `/digest` | POST | Daily browsing digest generation |

## Updating the Worker Code

1. Go to [dash.cloudflare.com](https://dash.cloudflare.com) → **Workers & Pages**
2. Select the **dpd-proxy** worker
3. Click **"Quick Edit"**
4. Replace code with contents of `worker.js`
5. Click **"Save and Deploy"**

## Environment Variables

The `GEMINI_API_KEY` environment variable should already be set.

If you need to update it:

1. Worker Settings → **Variables**
2. Edit `GEMINI_API_KEY`
3. Click **Encrypt** (recommended)
4. Save and Deploy

## Rate Limits

- **30 requests** per IP per hour
- **100 requests** per IP per day
- Rate limit data is stored in-memory (resets on worker restart)

## Caching

- Server-side in-memory cache
- **1 hour TTL** for all responses
- Max **500 cached entries** (LRU eviction)
- Identical queries return cached results without calling Gemini

## Security

- ✅ API key stored as encrypted environment variable
- ✅ Never exposed in responses or logs
- ✅ CORS configured for broad access
- ✅ Request size limited to 20KB
- ✅ Input validation on all endpoints
- ✅ Error responses never contain internal details
