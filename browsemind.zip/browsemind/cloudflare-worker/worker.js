/**
 * BrowseMind — Cloudflare Worker (AI Proxy)
 * Proxies AI search and digest requests to Gemini 2.0 Flash.
 * URL: https://dpd-proxy.ritik-yadav666888.workers.dev
 * 
 * Endpoints:
 *   POST /search — AI-powered browsing history search
 *   POST /digest — Daily browsing digest generation
 */

// ── Rate Limiting ──
const rateLimits = new Map(); // IP -> { hourly: { count, reset }, daily: { count, reset } }
const HOURLY_LIMIT = 30;
const DAILY_LIMIT = 100;

function checkRateLimit(ip) {
    const now = Date.now();
    let entry = rateLimits.get(ip);

    if (!entry) {
        entry = {
            hourly: { count: 0, reset: now + 3600000 },
            daily: { count: 0, reset: now + 86400000 }
        };
        rateLimits.set(ip, entry);
    }

    // Reset if expired
    if (now > entry.hourly.reset) {
        entry.hourly = { count: 0, reset: now + 3600000 };
    }
    if (now > entry.daily.reset) {
        entry.daily = { count: 0, reset: now + 86400000 };
    }

    if (entry.hourly.count >= HOURLY_LIMIT || entry.daily.count >= DAILY_LIMIT) {
        return false;
    }

    entry.hourly.count++;
    entry.daily.count++;
    rateLimits.set(ip, entry);

    // Cleanup old entries
    if (rateLimits.size > 10000) {
        const oldest = rateLimits.keys().next().value;
        rateLimits.delete(oldest);
    }

    return true;
}

// ── Server-side Cache ──
const cache = new Map();
const CACHE_TTL = 3600000; // 1 hour
const MAX_CACHE = 500;

function getCached(key) {
    const entry = cache.get(key);
    if (!entry) return null;
    if (Date.now() - entry.time > CACHE_TTL) {
        cache.delete(key);
        return null;
    }
    return entry.data;
}

function setCache(key, data) {
    if (cache.size >= MAX_CACHE) {
        const oldest = cache.keys().next().value;
        cache.delete(oldest);
    }
    cache.set(key, { data, time: Date.now() });
}

function hashStr(str) {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
        hash = ((hash << 5) - hash) + str.charCodeAt(i);
        hash = hash & hash;
    }
    return Math.abs(hash).toString(36);
}

// ── CORS Headers ──
const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
};

// ── Main Handler ──
export default {
    async fetch(request, env) {
        // Handle preflight
        if (request.method === 'OPTIONS') {
            return new Response(null, { status: 204, headers: corsHeaders });
        }

        // Only POST
        if (request.method !== 'POST') {
            return jsonResponse({ error: 'Method not allowed' }, 405);
        }

        // Get client IP
        const ip = request.headers.get('CF-Connecting-IP') || 'unknown';

        // Rate limit check
        if (!checkRateLimit(ip)) {
            return jsonResponse({ error: 'Rate limit exceeded. Try again later.' }, 429);
        }

        try {
            // Parse body
            const contentType = request.headers.get('Content-Type') || '';
            if (!contentType.includes('application/json')) {
                return jsonResponse({ error: 'Content-Type must be application/json' }, 400);
            }

            const body = await request.text();
            if (body.length > 20480) { // 20KB max
                return jsonResponse({ error: 'Request too large' }, 400);
            }

            let data;
            try {
                data = JSON.parse(body);
            } catch {
                return jsonResponse({ error: 'Invalid JSON' }, 400);
            }

            const { action } = data;

            // Route to handler
            const url = new URL(request.url);
            const path = url.pathname;

            if (path === '/search' || action === 'search') {
                return await handleSearch(data, env);
            } else if (path === '/digest' || action === 'digest') {
                return await handleDigest(data, env);
            } else {
                return jsonResponse({ error: 'Unknown action' }, 400);
            }

        } catch (err) {
            console.error('Worker error:', err);
            return jsonResponse({ error: 'Internal error' }, 500);
        }
    }
};

// ── Search Handler ──
async function handleSearch(data, env) {
    const { query, pages } = data;

    // Validate
    if (!query || typeof query !== 'string' || query.length < 3 || query.length > 500) {
        return jsonResponse({ error: 'Query must be 3-500 characters' }, 400);
    }
    if (!pages || typeof pages !== 'string' || pages.length > 15000) {
        return jsonResponse({ error: 'Pages data invalid or too large' }, 400);
    }

    // Check cache
    const cacheKey = 'search_' + hashStr(query + pages.substring(0, 200));
    const cached = getCached(cacheKey);
    if (cached) {
        return jsonResponse(cached);
    }

    // Build Gemini prompt
    const prompt = `You are BrowseMind Search — an AI that helps users find pages they previously visited based on natural language queries.

The user is searching their browsing history. They describe what they remember about a page they visited. Your job is to find the most relevant pages from their history.

USER'S SEARCH QUERY:
"${query}"

THEIR BROWSING HISTORY (format: ID | Title | Domain | Date | Description):
${pages}

INSTRUCTIONS:
1. Understand what the user is looking for based on their query
2. Find the pages most likely to match their description
3. Consider: topic relevance, keywords, domain, date hints in query
4. If user mentions "last week" or "yesterday" or "recently", factor in dates
5. If user mentions a specific site, prioritize that domain
6. Return the IDs of matching pages, ranked by relevance

RESPOND IN THIS EXACT JSON FORMAT ONLY (no markdown, no code blocks):
{
  "results": [
    {
      "id": <page ID number>,
      "relevance": <1-100 score>,
      "reason": "<why this matches, max 15 words>"
    }
  ],
  "interpretation": "<what you understood the user is looking for, max 20 words>"
}

Return maximum 10 results. Only include results with relevance >= 50.
If nothing matches well, return empty results array with interpretation explaining why.`;

    const result = await callGemini(prompt, env, 0.1, 500);
    if (result.error) {
        return jsonResponse({ error: result.error }, result.status || 502);
    }

    // Cache and return
    setCache(cacheKey, result.data);
    return jsonResponse(result.data);
}

// ── Digest Handler ──
async function handleDigest(data, env) {
    const { data: browsingData } = data;

    // Validate
    if (!browsingData || typeof browsingData !== 'string' || browsingData.length > 10000) {
        return jsonResponse({ error: 'Browsing data invalid or too large' }, 400);
    }

    // Check cache
    const cacheKey = 'digest_' + hashStr(browsingData.substring(0, 300));
    const cached = getCached(cacheKey);
    if (cached) {
        return jsonResponse(cached);
    }

    const prompt = `You are BrowseMind Digest — an AI that creates insightful daily browsing summaries.

Here is a user's browsing data for a day:
${browsingData}

Create an engaging, insightful digest of their browsing day.

RESPOND IN THIS EXACT JSON FORMAT ONLY (no markdown, no code blocks):
{
  "totalPages": <number>,
  "totalTime": "<human readable like '2.3 hours'>",
  "topTopics": ["<topic 1>", "<topic 2>", "<topic 3>", "<topic 4>", "<topic 5>"],
  "topSites": [
    {"domain": "<site>", "visits": <count>, "emoji": "<relevant emoji>"}
  ],
  "highlight": "<most interesting page they visited, with title and why it stands out, max 30 words>",
  "insight": "<one interesting observation about their browsing pattern, max 30 words>",
  "funFact": "<a fun or surprising stat about their day, max 20 words>",
  "productivity": "<percentage estimate of work vs personal browsing>"
}

Be friendly, insightful, and slightly witty. Make the user feel good about their browsing while providing genuine insights.`;

    const result = await callGemini(prompt, env, 0.5, 600);
    if (result.error) {
        return jsonResponse({ error: result.error }, result.status || 502);
    }

    setCache(cacheKey, result.data);
    return jsonResponse(result.data);
}

// ── Gemini API Call ──
async function callGemini(prompt, env, temperature = 0.1, maxTokens = 500) {
    const apiKey = env.GEMINI_API_KEY;
    if (!apiKey) {
        return { error: 'AI service not configured', status: 500 };
    }

    const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${apiKey}`;

    try {
        const response = await fetch(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                contents: [{
                    parts: [{ text: prompt }]
                }],
                generationConfig: {
                    temperature,
                    maxOutputTokens: maxTokens,
                    responseMimeType: 'application/json'
                }
            })
        });

        if (response.status === 429) {
            return { error: 'AI service is busy. Please try again later.', status: 503 };
        }

        if (!response.ok) {
            console.error('Gemini error:', response.status);
            return { error: 'AI service temporarily unavailable.', status: 502 };
        }

        const result = await response.json();

        // Extract text from Gemini response
        const text = result?.candidates?.[0]?.content?.parts?.[0]?.text;
        if (!text) {
            return { error: 'AI returned empty response.', status: 502 };
        }

        // Parse JSON from response
        try {
            // Clean possible markdown code block wrapping
            const cleaned = text.replace(/```json\n?/g, '').replace(/```\n?/g, '').trim();
            const parsed = JSON.parse(cleaned);
            return { data: parsed };
        } catch {
            console.error('Failed to parse Gemini response:', text);
            return { error: 'AI returned invalid response.', status: 502 };
        }

    } catch (err) {
        console.error('Gemini fetch error:', err);
        return { error: 'AI service connection failed.', status: 502 };
    }
}

// ── Helper ──
function jsonResponse(data, status = 200) {
    return new Response(JSON.stringify(data), {
        status,
        headers: {
            'Content-Type': 'application/json',
            ...corsHeaders
        }
    });
}
