/**
 * BrowseMind — AI-Powered Search
 * Sends search queries to Cloudflare Worker proxy for AI-powered ranking.
 * Used when local search is insufficient or user explicitly requests AI.
 */

const PROXY_URL = "https://dpd-proxy.ritik-yadav666888.workers.dev";

// In-memory cache for AI search results (1 hour TTL)
const searchCache = new Map();
const CACHE_TTL = 60 * 60 * 1000; // 1 hour

/**
 * Simple hash function for cache keys
 */
function hashKey(str) {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
        const char = str.charCodeAt(i);
        hash = ((hash << 5) - hash) + char;
        hash = hash & hash;
    }
    return 'bm_search_' + Math.abs(hash).toString(36);
}

/**
 * Format pages into compact one-line summaries for the AI
 */
function formatPagesForAI(pages) {
    return pages.map(page => {
        const date = page.date || new Date(page.timestamp).toISOString().split('T')[0];
        const desc = (page.description || page.contentPreview || '').substring(0, 80);
        return `${page.id} | ${(page.title || 'Untitled').substring(0, 60)} | ${page.domain} | ${date} | ${desc}`;
    }).join('\n');
}

/**
 * Perform AI-powered search via Cloudflare proxy
 * @param {string} query - User's natural language search query
 * @param {Array} pages - Array of page records to search through
 * @returns {Promise<Object>} AI search results with ranked page IDs
 */
export async function searchAI(query, pages) {
    try {
        // Check cache first
        const cacheKey = hashKey(query.toLowerCase().trim());
        const cached = searchCache.get(cacheKey);
        if (cached && (Date.now() - cached.time) < CACHE_TTL) {
            return { ...cached.data, fromCache: true };
        }

        // Format pages for AI
        const pagesStr = formatPagesForAI(pages);

        // Validate
        if (!query || query.length < 3 || query.length > 500) {
            return { error: 'Query must be between 3 and 500 characters' };
        }

        if (pagesStr.length > 15000) {
            // Truncate if too long
            const truncatedPages = pages.slice(0, 30);
            return searchAI(query, truncatedPages);
        }

        // Call proxy
        const response = await fetch(PROXY_URL + '/search', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                action: 'search',
                query: query,
                pages: pagesStr
            })
        });

        if (!response.ok) {
            if (response.status === 429) {
                return { error: 'AI search is busy. Please try again in a few minutes.' };
            }
            return { error: 'AI search unavailable right now.' };
        }

        const data = await response.json();

        // Cache the results
        searchCache.set(cacheKey, { data, time: Date.now() });

        // Evict old cache entries
        if (searchCache.size > 50) {
            const oldestKey = searchCache.keys().next().value;
            searchCache.delete(oldestKey);
        }

        return data;
    } catch (err) {
        console.error('BrowseMind: AI search error', err);
        return { error: 'AI search unavailable right now. Showing local results.' };
    }
}

/**
 * Clear the search cache
 */
export function clearSearchCache() {
    searchCache.clear();
}
