/**
 * BrowseMind — Local Keyword Search
 * Searches IndexedDB using keyword matching. Zero API calls.
 * Used as the first search method for instant results.
 */

const STOP_WORDS = new Set([
    'the', 'a', 'an', 'is', 'was', 'were', 'are', 'in', 'on', 'at', 'to',
    'for', 'of', 'and', 'or', 'but', 'that', 'this', 'it', 'with', 'from',
    'by', 'be', 'been', 'being', 'have', 'has', 'had', 'do', 'does', 'did',
    'will', 'would', 'could', 'should', 'may', 'might', 'can', 'shall',
    'not', 'no', 'so', 'if', 'then', 'than', 'too', 'very', 'just',
    'about', 'up', 'out', 'all', 'also', 'as', 'its', 'my', 'me',
    'we', 'he', 'she', 'they', 'them', 'what', 'which', 'who', 'when',
    'where', 'how', 'i'
]);

/**
 * Search pages locally by keyword matching
 * @param {IDBDatabase} db - The IndexedDB database instance
 * @param {string} query - Search query string
 * @param {number} limit - Max results to return
 * @returns {Promise<Array>} Scored and sorted results
 */
export async function searchLocal(db, query, limit = 15) {
    try {
        // Clean and tokenize query
        const cleaned = query.toLowerCase().trim().replace(/\s+/g, ' ');
        const keywords = cleaned.split(' ')
            .filter(k => k.length > 1 && !STOP_WORDS.has(k));

        if (keywords.length === 0) return [];

        const tx = db.transaction('pages', 'readonly');
        const store = tx.objectStore('pages');

        return new Promise((resolve, reject) => {
            const scored = [];
            const request = store.openCursor();

            request.onsuccess = (event) => {
                const cursor = event.target.result;
                if (!cursor) {
                    // Sort by score descending, then by recency
                    scored.sort((a, b) => b.score - a.score || b.timestamp - a.timestamp);
                    resolve(scored.slice(0, limit));
                    return;
                }

                const record = cursor.value;
                let score = 0;

                const title = (record.title || '').toLowerCase();
                const domain = (record.domain || '').toLowerCase();
                const headings = (record.headings || '').toLowerCase();
                const description = (record.description || '').toLowerCase();
                const contentPreview = (record.contentPreview || '').toLowerCase();

                for (const kw of keywords) {
                    if (title.includes(kw)) score += 10;
                    if (domain.includes(kw)) score += 8;
                    if (headings.includes(kw)) score += 6;
                    if (description.includes(kw)) score += 4;
                    if (contentPreview.includes(kw)) score += 2;
                }

                if (score > 0) {
                    // Recency bonus
                    const daysSince = (Date.now() - record.timestamp) / 86400000;
                    if (daysSince < 1) score += 5;
                    else if (daysSince < 3) score += 3;
                    else if (daysSince < 7) score += 1;

                    // Time spent bonus
                    if (record.timeSpent > 120) score += 3;
                    else if (record.timeSpent > 60) score += 1;

                    scored.push({ ...record, score });
                }

                cursor.continue();
            };

            request.onerror = () => reject(request.error);
        });
    } catch (err) {
        console.error('BrowseMind: localSearch error', err);
        return [];
    }
}

/**
 * Get top N pages by recency for AI search context
 */
export async function getTopPagesForAI(db, limit = 50) {
    try {
        const tx = db.transaction('pages', 'readonly');
        const store = tx.objectStore('pages');
        const index = store.index('timestamp');

        return new Promise((resolve, reject) => {
            const results = [];
            const request = index.openCursor(null, 'prev');

            request.onsuccess = (event) => {
                const cursor = event.target.result;
                if (!cursor || results.length >= limit) {
                    resolve(results);
                    return;
                }
                results.push(cursor.value);
                cursor.continue();
            };

            request.onerror = () => reject(request.error);
        });
    } catch (err) {
        console.error('BrowseMind: getTopPagesForAI error', err);
        return [];
    }
}
