/**
 * BrowseMind — Full Page Controller
 * Expanded search, history, digest, and stats views.
 */

document.addEventListener('DOMContentLoaded', init);

let historyOffset = 0;
const HISTORY_LIMIT = 30;
let fpDigestDate = new Date();

function sendMessage(msg) {
    return new Promise(resolve => {
        try {
            chrome.runtime.sendMessage(msg, r => {
                if (chrome.runtime.lastError) {
                    console.warn('[BrowseMind FP] sendMessage error:', chrome.runtime.lastError.message);
                    resolve({});
                    return;
                }
                resolve(r || {});
            });
        } catch (err) {
            console.warn('[BrowseMind FP] sendMessage exception:', err);
            resolve({});
        }
    });
}

function timeAgo(ts) {
    const s = Math.floor((Date.now() - ts) / 1000);
    if (s < 60) return 'just now';
    if (s < 3600) { const m = Math.floor(s / 60); return `${m} min${m > 1 ? 's' : ''} ago`; }
    if (s < 86400) { const h = Math.floor(s / 3600); return `${h} hour${h > 1 ? 's' : ''} ago`; }
    const d = Math.floor(s / 86400);
    return `${d} day${d > 1 ? 's' : ''} ago`;
}

function esc(t) { if (!t) return ''; const d = document.createElement('div'); d.textContent = t; return d.innerHTML; }
function trunc(t, m = 120) { return !t ? '' : t.length <= m ? t : t.substring(0, m) + '...'; }
function favUrl(domain) { return domain ? `https://www.google.com/s2/favicons?domain=${domain}&sz=32` : ''; }

function formatDateNice(ds) {
    return new Date(ds + 'T00:00:00').toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
}

function formatDuration(sec) {
    if (!sec || sec < 60) return '< 1 min';
    if (sec < 3600) return Math.floor(sec / 60) + ' mins';
    return (sec / 3600).toFixed(1) + ' hours';
}

function init() {
    setupNav();
    setupSearch();
    setupHistory();
    setupDigest();
    switchSection('search');
}

// ── Navigation ──
function setupNav() {
    document.querySelectorAll('.fp-nav-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const section = btn.dataset.section;
            if (section === 'settings') {
                chrome.tabs.create({ url: chrome.runtime.getURL('settings/settings.html') });
                return;
            }
            switchSection(section);
        });
    });
}

function switchSection(name) {
    document.querySelectorAll('.fp-nav-btn').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.fp-section').forEach(s => s.classList.remove('active'));
    document.querySelector(`.fp-nav-btn[data-section="${name}"]`)?.classList.add('active');
    document.getElementById(`section-${name}`)?.classList.add('active');

    if (name === 'history') loadHistory();
    if (name === 'stats') loadStats();
    if (name === 'digest') loadFPDigest();
}

// ── Search ──
function setupSearch() {
    document.getElementById('fpSearchBtn').addEventListener('click', doFPSearch);
    document.getElementById('fpSearchInput').addEventListener('keydown', e => {
        if (e.key === 'Enter') doFPSearch();
    });
}

async function doFPSearch() {
    const query = document.getElementById('fpSearchInput').value.trim();
    if (!query) return;

    const resp = await sendMessage({
        action: 'searchWithFilters',
        query,
        domain: document.getElementById('fpDomainFilter').value.trim() || undefined,
        startDate: document.getElementById('fpDateFrom').value || undefined,
        endDate: document.getElementById('fpDateTo').value || undefined,
        sortBy: document.getElementById('fpSortBy').value,
        limit: 30
    });

    const container = document.getElementById('fpSearchResults');
    container.innerHTML = '';

    if (!resp.results || resp.results.length === 0) {
        container.innerHTML = '<p style="text-align:center;color:var(--text-muted);padding:20px">No results found</p>';
        return;
    }

    resp.results.forEach((page, i) => {
        container.appendChild(createFPCard(page, i));
    });
}

// ── History ──
function setupHistory() {
    document.getElementById('fpHistoryMoreBtn').addEventListener('click', async () => {
        historyOffset += HISTORY_LIMIT;
        const resp = await sendMessage({ action: 'getRecentPages', limit: HISTORY_LIMIT, offset: historyOffset });
        const pages = resp.pages || [];
        const container = document.getElementById('fpHistoryList');
        pages.forEach((p, i) => container.appendChild(createFPCard(p, i, true)));
        document.getElementById('fpHistoryLoadMore').style.display = pages.length >= HISTORY_LIMIT ? 'block' : 'none';
    });

    document.getElementById('fpBulkDelete').addEventListener('click', async () => {
        if (!confirm('Delete all filtered history? This cannot be undone.')) return;
        // Delete visible items
        const cards = document.querySelectorAll('#fpHistoryList .fp-page-card');
        for (const card of cards) {
            const id = parseInt(card.dataset.id);
            if (id) await sendMessage({ action: 'deletePage', id });
        }
        loadHistory();
    });
}

async function loadHistory() {
    historyOffset = 0;
    const resp = await sendMessage({ action: 'getRecentPages', limit: HISTORY_LIMIT, offset: 0 });
    const pages = resp.pages || [];
    const container = document.getElementById('fpHistoryList');
    container.innerHTML = '';

    if (pages.length === 0) {
        container.innerHTML = '<p style="text-align:center;color:var(--text-muted);padding:40px">No browsing memories yet</p>';
        return;
    }

    let lastDate = '';
    pages.forEach((page, i) => {
        const pd = page.date || new Date(page.timestamp).toISOString().split('T')[0];
        if (pd !== lastDate) {
            const label = document.createElement('h3');
            label.style.cssText = 'font-size:13px;color:var(--text-secondary);margin:16px 0 8px;text-transform:uppercase;letter-spacing:0.5px';
            label.textContent = formatDateNice(pd);
            container.appendChild(label);
            lastDate = pd;
        }
        container.appendChild(createFPCard(page, i, true));
    });

    document.getElementById('fpHistoryLoadMore').style.display = pages.length >= HISTORY_LIMIT ? 'block' : 'none';
}

// ── Digest ──
function setupDigest() {
    document.getElementById('fpDigestPrev').addEventListener('click', () => {
        fpDigestDate.setDate(fpDigestDate.getDate() - 1);
        loadFPDigest();
    });
    document.getElementById('fpDigestNext').addEventListener('click', () => {
        fpDigestDate.setDate(fpDigestDate.getDate() + 1);
        loadFPDigest();
    });
    document.getElementById('fpDigestGenBtn').addEventListener('click', generateFPDigest);
}

async function loadFPDigest() {
    const dateStr = fpDigestDate.toISOString().split('T')[0];
    const today = new Date().toISOString().split('T')[0];

    document.getElementById('fpDigestDate').textContent = dateStr === today ? 'Today — ' + formatDateNice(dateStr) : formatDateNice(dateStr);
    document.getElementById('fpDigestNext').disabled = dateStr >= today;
    document.getElementById('fpDigestContent').innerHTML = '';
    document.getElementById('fpDigestGenerate').style.display = 'none';
    document.getElementById('fpDigestLoading').style.display = 'none';
    document.getElementById('fpDigestPagesHeading').style.display = 'none';
    document.getElementById('fpDigestPagesList').innerHTML = '';

    // Check page count first
    const pagesResp = await sendMessage({ action: 'getPagesByDate', date: dateStr });
    if (!pagesResp.pages || pagesResp.pages.length < 5) {
        document.getElementById('fpDigestContent').innerHTML = '<p style="text-align:center;color:var(--text-muted);padding:20px">Not enough data for this day.</p>';
        if (pagesResp.pages && pagesResp.pages.length > 0) await loadDayPages(dateStr);
        return;
    }

    document.getElementById('fpDigestGenerate').style.display = 'block';
    await loadDayPages(dateStr);
}

async function generateFPDigest() {
    const dateStr = fpDigestDate.toISOString().split('T')[0];
    document.getElementById('fpDigestGenerate').style.display = 'none';
    document.getElementById('fpDigestLoading').style.display = 'block';

    const resp = await sendMessage({ action: 'generateDigest', date: dateStr });
    document.getElementById('fpDigestLoading').style.display = 'none';

    if (resp.error) {
        document.getElementById('fpDigestContent').innerHTML = `<p style="text-align:center;color:var(--text-muted)">${esc(resp.error)}</p>`;
        document.getElementById('fpDigestGenerate').style.display = 'block';
        return;
    }

    if (resp.digest) renderFPDigest(resp.digest);
}

function renderFPDigest(digest) {
    const container = document.getElementById('fpDigestContent');
    container.innerHTML = '';

    // Stats
    const stats = document.createElement('div');
    stats.className = 'digest-section';
    stats.innerHTML = `<div class="digest-stats-row">
    <span>📄 ${digest.totalPages || '?'} pages</span>
    <span>⏱️ ${digest.totalTime || '?'}</span>
  </div>`;
    container.appendChild(stats);

    // Topics
    if (digest.topTopics?.length > 0) {
        const t = document.createElement('div');
        t.className = 'digest-section';
        const emojis = ['💻', '🤖', '🛒', '📰', '🍳', '🎮', '📚', '🎵', '💼', '🔬'];
        t.innerHTML = `<div class="digest-label">🏷️ Top Topics</div>
      <div class="topic-pills">${digest.topTopics.map((tp, i) => `<span class="topic-pill">${emojis[i] || '📌'} ${esc(tp)}</span>`).join('')}</div>`;
        container.appendChild(t);
    }

    // Top sites
    if (digest.topSites?.length > 0) {
        const maxV = Math.max(...digest.topSites.map(s => s.visits));
        const s = document.createElement('div');
        s.className = 'digest-section';
        s.innerHTML = `<div class="digest-label">🌐 Top Sites</div>
      ${digest.topSites.map(st => `<div class="domain-bar-row">
        <span class="domain-bar-label">${st.emoji || '🌐'} ${esc(st.domain)}</span>
        <div class="domain-bar-track"><div class="domain-bar-fill" style="width:${(st.visits / maxV) * 100}%"></div></div>
        <span class="domain-bar-count">${st.visits}</span>
      </div>`).join('')}`;
        container.appendChild(s);
    }

    // Highlight, insight, fun fact
    ['highlight', 'insight', 'funFact'].forEach(key => {
        if (digest[key]) {
            const icons = { highlight: '⭐', insight: '💡', funFact: '🎲' };
            const labels = { highlight: 'Highlight', insight: 'Insight', funFact: 'Fun Fact' };
            const d = document.createElement('div');
            d.className = 'digest-section';
            d.innerHTML = `<div class="digest-label">${icons[key]} ${labels[key]}</div><div style="font-size:13px;color:var(--text-secondary)">${esc(digest[key])}</div>`;
            container.appendChild(d);
        }
    });

    // Productivity
    if (digest.productivity) {
        const wp = parseInt(digest.productivity) || 50;
        const p = document.createElement('div');
        p.className = 'digest-section';
        p.innerHTML = `<div class="digest-label">📈 Productivity</div>
      <div class="productivity-label">${wp}% work · ${100 - wp}% personal</div>
      <div class="productivity-bar"><div class="productivity-work" style="width:${wp}%"></div><div class="productivity-personal"></div></div>`;
        container.appendChild(p);
    }
}

async function loadDayPages(dateStr) {
    const resp = await sendMessage({ action: 'getPagesByDate', date: dateStr });
    const pages = resp.pages || [];
    if (pages.length === 0) return;

    document.getElementById('fpDigestPagesHeading').style.display = 'block';
    const list = document.getElementById('fpDigestPagesList');
    list.innerHTML = '';
    pages.forEach((p, i) => list.appendChild(createFPCard(p, i)));
}

// ── Stats ──
async function loadStats() {
    const stats = await sendMessage({ action: 'getAllTimeStats' });
    const grid = document.getElementById('statsGrid');
    grid.innerHTML = '';

    const items = [
        { value: stats.totalPages || 0, label: 'Pages Remembered', icon: '📄' },
        { value: formatDuration(stats.totalTimeSpent || 0), label: 'Total Browsing Time', icon: '⏱️' },
        { value: stats.uniqueDomains || 0, label: 'Unique Websites', icon: '🌐' },
        { value: (stats.estimatedSizeMB || '0') + ' MB', label: 'Data Stored', icon: '💾' },
        { value: stats.earliestDate || 'N/A', label: 'First Memory', icon: '📅' }
    ];

    items.forEach((item, i) => {
        const card = document.createElement('div');
        card.className = 'stat-card';
        card.style.animationDelay = `${i * 80}ms`;
        card.innerHTML = `<div class="stat-value">${item.icon} ${item.value}</div><div class="stat-label">${item.label}</div>`;
        grid.appendChild(card);
    });

    // Top domains
    const domainsResp = await sendMessage({ action: 'getTopDomains', days: 9999, limit: 10 });
    const domainsContainer = document.getElementById('statsDomains');
    domainsContainer.innerHTML = '';

    if (domainsResp.domains && domainsResp.domains.length > 0) {
        const maxCount = domainsResp.domains[0].count;
        domainsContainer.innerHTML = `<h3>🏆 Most Visited Domains (All Time)</h3>
      ${domainsResp.domains.map(d => `<div class="domain-bar-row">
        <span class="domain-bar-label">${esc(d.domain)}</span>
        <div class="domain-bar-track"><div class="domain-bar-fill" style="width:${(d.count / maxCount) * 100}%"></div></div>
        <span class="domain-bar-count">${d.count}</span>
      </div>`).join('')}`;
    }
}

// ── Card Builder ──
function createFPCard(page, index, showDelete = false) {
    const card = document.createElement('div');
    card.className = 'fp-page-card';
    card.style.animationDelay = `${index * 40}ms`;
    card.dataset.id = page.id;

    const meta = [esc(page.domain), timeAgo(page.timestamp)].filter(Boolean).join(' · ');

    card.innerHTML = `
    <img class="fp-card-favicon" src="${favUrl(page.domain)}" alt="" onerror="this.style.display='none'">
    <div class="fp-card-body">
      <div class="fp-card-title">${esc(page.title || 'Untitled')}</div>
      <div class="fp-card-meta">${meta}</div>
      <div class="fp-card-preview">${esc(trunc(page.contentPreview || page.description))}</div>
    </div>
    <div class="fp-card-actions">
      ${showDelete ? `<button class="fp-card-btn" data-action="delete" data-id="${page.id}">🗑️</button>` : ''}
      <button class="fp-card-btn" data-action="open" data-url="${esc(page.url)}">🔗</button>
    </div>`;

    card.addEventListener('click', e => {
        if (e.target.closest('.fp-card-btn')) return;
        chrome.tabs.create({ url: page.url });
    });

    card.querySelector('[data-action="open"]')?.addEventListener('click', e => {
        e.stopPropagation();
        chrome.tabs.create({ url: page.url });
    });

    card.querySelector('[data-action="delete"]')?.addEventListener('click', async e => {
        e.stopPropagation();
        await sendMessage({ action: 'deletePage', id: page.id });
        card.style.opacity = '0';
        card.style.transform = 'translateX(20px)';
        card.style.transition = 'all 0.2s';
        setTimeout(() => card.remove(), 200);
    });

    return card;
}
