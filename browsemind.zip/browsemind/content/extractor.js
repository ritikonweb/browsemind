/**
 * BrowseMind — Content Extractor
 * Injected into pages by background.js after 30 seconds of active time.
 * Extracts page content for memory storage. ZERO API calls.
 * Runs in page context as a content script.
 */

(function () {
    'use strict';

    // Prevent running multiple times on same page
    if (window.__browsemind_extracted) return;
    window.__browsemind_extracted = true;

    try {
        // 1. TITLE
        const title = (document.title || '').trim().substring(0, 300);

        // 2. URL
        const url = window.location.href;

        // 3. DOMAIN
        const domain = window.location.hostname;

        // 4. META DESCRIPTION
        const description = (
            document.querySelector('meta[name="description"]')?.getAttribute('content') ||
            document.querySelector('meta[property="og:description"]')?.getAttribute('content') ||
            ''
        ).trim().substring(0, 500);

        // 5. MAIN HEADINGS (first 10 h1/h2/h3, max 300 chars total)
        const headingElements = document.querySelectorAll('h1, h2, h3');
        const headingsArr = [];
        let headingsTotalLen = 0;

        for (let i = 0; i < Math.min(headingElements.length, 10); i++) {
            const text = headingElements[i].textContent.trim();
            if (text && headingsTotalLen + text.length <= 300) {
                headingsArr.push(text);
                headingsTotalLen += text.length;
            }
        }
        const headings = headingsArr.join(', ');

        // 6. MAIN CONTENT SUMMARY (first 500 chars of main content)
        let mainContent = '';

        const selectors = [
            'article',
            '[role="main"]',
            'main',
            '.content', '.post', '.article', '.entry', '.story',
            '#content', '#main', '#article',
            '.post-content', '.article-content', '.entry-content'
        ];

        for (const sel of selectors) {
            const el = document.querySelector(sel);
            if (el && el.innerText && el.innerText.trim().length > 100) {
                mainContent = el.innerText.trim();
                break;
            }
        }

        // Fallback to body text
        if (!mainContent || mainContent.length < 100) {
            mainContent = document.body?.innerText || '';
        }

        // Clean up: remove excessive whitespace, take first 500 chars
        const contentPreview = mainContent
            .replace(/\s+/g, ' ')
            .trim()
            .substring(0, 500);

        // 7. FAVICON URL
        const favicon = (
            document.querySelector('link[rel="icon"]')?.href ||
            document.querySelector('link[rel="shortcut icon"]')?.href ||
            document.querySelector('link[rel="apple-touch-icon"]')?.href ||
            `https://${domain}/favicon.ico`
        );

        // 8. OG IMAGE
        const ogImage = (
            document.querySelector('meta[property="og:image"]')?.getAttribute('content') || ''
        );

        // 9. LANGUAGE
        const language = document.documentElement.lang || 'en';

        // 10. WORD COUNT
        const bodyText = document.body?.innerText || '';
        const wordCount = bodyText.split(/\s+/).filter(w => w.length > 0).length;

        // Validate: skip pages with too little content
        if (bodyText.trim().length < 100) {
            return; // Not enough content — likely a redirect or loading page
        }

        // Build output data
        const pageData = {
            title,
            url,
            domain,
            description,
            headings,
            contentPreview,
            favicon,
            ogImage,
            language,
            wordCount
        };

        // Send data back to background.js
        chrome.runtime.sendMessage({
            action: 'contentExtracted',
            data: pageData
        });

    } catch (err) {
        // Silently fail — do not show errors to user
        console.debug('BrowseMind extractor: silent skip', err.message);
    }
})();
