/**
 * BrowseMind — Background Service Worker v1.2.0
 * THREE-PRONGED CAPTURE: Save-on-Exit + Alarm + Periodic Sweep
 * Single file, no imports, no modules.
 *
 * Method 1: SAVE ON EXIT — when user navigates, switches tab, or closes tab
 * Method 2: ALARM — 30s after page load, save if still on that page
 * Method 3: SWEEP — every 2 min, check ALL open tabs for unsaved pages
 *
 * Deduplication: same URL within 2h → update timeSpent, never duplicate.
 */

// ══════════════════════════════════════════════════════
// CONSTANTS
// ══════════════════════════════════════════════════════

const DB_NAME = 'BrowseMindDB';
const DB_VERSION = 1;
const PROXY_URL = 'https://dpd-proxy.ritik-yadav666888.workers.dev';
const DAILY_AI_LIMIT = 20;
const DEFAULT_MIN_TIME = 10; // seconds

const SKIP_PREFIXES = [
    'chrome://', 'chrome-extension://', 'edge://', 'about:',
    'moz-extension://', 'devtools://', 'brave://', 'opera://',
    'vivaldi://', 'data:', 'blob:', 'file://', 'chrome-search://'
];
const SKIP_DOMAINS = ['chrome.google.com', 'chromewebstore.google.com', 'microsoftedge.microsoft.com'];

// ── Local date helpers (NEVER use toISOString for dates — it returns UTC!) ──
function getLocalDate(d) {
    if (!d) d = new Date();
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return y + '-' + m + '-' + day;
}
function getLocalDateFromTimestamp(ts) { return getLocalDate(new Date(ts)); }

const STOP_WORDS = new Set([
    'the', 'a', 'an', 'is', 'was', 'were', 'are', 'in', 'on', 'at', 'to',
    'for', 'of', 'and', 'or', 'but', 'that', 'this', 'it', 'with', 'from',
    'by', 'be', 'been', 'being', 'have', 'has', 'had', 'do', 'does', 'did',
    'will', 'would', 'could', 'should', 'may', 'might', 'can', 'shall',
    'not', 'no', 'so', 'if', 'then', 'than', 'too', 'very', 'just',
    'about', 'up', 'out', 'all', 'also', 'as', 'its', 'my', 'me',
    'we', 'he', 'she', 'they', 'them', 'what', 'which', 'who', 'when',
    'where', 'how', 'i', 'you', 'your', 'our'
]);

// ══════════════════════════════════════════════════════
// SECTION 1: IndexedDB — fresh connection every time
// ══════════════════════════════════════════════════════

function getDB() {
    return new Promise((resolve, reject) => {
        try {
            const request = indexedDB.open(DB_NAME, DB_VERSION);
            request.onupgradeneeded = (e) => {
                const db = e.target.result;
                if (!db.objectStoreNames.contains('pages')) {
                    const s = db.createObjectStore('pages', { keyPath: 'id', autoIncrement: true });
                    s.createIndex('url', 'url', { unique: false });
                    s.createIndex('domain', 'domain', { unique: false });
                    s.createIndex('timestamp', 'timestamp', { unique: false });
                    s.createIndex('title', 'title', { unique: false });
                    s.createIndex('date', 'date', { unique: false });
                }
                if (!db.objectStoreNames.contains('settings')) {
                    db.createObjectStore('settings', { keyPath: 'key' });
                }
                if (!db.objectStoreNames.contains('digestCache')) {
                    db.createObjectStore('digestCache', { keyPath: 'date' });
                }
            };
            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        } catch (err) { reject(err); }
    });
}

// ── Save page with built-in deduplication ──
async function savePage(pageData) {
    try {
        const db = await getDB();
        const now = Date.now();
        const today = getLocalDate();
        const twoHoursAgo = now - 2 * 3600000;

        const searchText = [
            pageData.title || '', pageData.description || '',
            pageData.headings || '', pageData.contentPreview || '',
            pageData.domain || ''
        ].join(' ').toLowerCase();

        // Check for recent duplicate
        const duplicate = await new Promise((resolve) => {
            const tx = db.transaction('pages', 'readonly');
            const idx = tx.objectStore('pages').index('url');
            const req = idx.getAll(pageData.url);
            req.onsuccess = () => {
                const existing = (req.result || []).find(p => p.timestamp > twoHoursAgo);
                resolve(existing || null);
            };
            req.onerror = () => resolve(null);
        });

        if (duplicate) {
            // Update existing: accumulate time, enrich content if better
            const tx = db.transaction('pages', 'readwrite');
            const store = tx.objectStore('pages');
            duplicate.timeSpent = Math.max(duplicate.timeSpent || 0, pageData.timeSpent || 0);
            duplicate.timestamp = now;
            if (pageData.title && pageData.title !== pageData.url && pageData.title !== pageData.domain) {
                duplicate.title = pageData.title;
            }
            if (pageData.contentPreview && pageData.contentPreview.length > (duplicate.contentPreview || '').length) {
                duplicate.contentPreview = pageData.contentPreview;
                duplicate.description = pageData.description || duplicate.description;
                duplicate.headings = pageData.headings || duplicate.headings;
                duplicate.wordCount = pageData.wordCount || duplicate.wordCount;
                duplicate.searchText = searchText;
            }
            store.put(duplicate);
            await new Promise(r => { tx.oncomplete = r; tx.onerror = r; });
            db.close();
            console.log('[BrowseMind] Updated existing:', duplicate.title, '(+' + (pageData.timeSpent || 0) + 's)');
            return 'updated';
        }

        // No duplicate — insert new record
        const record = {
            title: pageData.title || '',
            url: pageData.url || '',
            domain: pageData.domain || '',
            description: pageData.description || '',
            headings: pageData.headings || '',
            contentPreview: pageData.contentPreview || '',
            favicon: pageData.favicon || '',
            ogImage: pageData.ogImage || '',
            language: pageData.language || 'en',
            wordCount: pageData.wordCount || 0,
            timestamp: now,
            date: today,
            timeSpent: pageData.timeSpent || 10,
            searchText
        };
        const tx = db.transaction('pages', 'readwrite');
        tx.objectStore('pages').add(record);
        await new Promise(r => { tx.oncomplete = r; tx.onerror = r; });
        db.close();
        console.log('[BrowseMind] ✅ Saved NEW:', record.title, '(' + record.timeSpent + 's)');
        return 'saved';
    } catch (err) {
        console.error('[BrowseMind] savePage error:', err.message);
        return 'error';
    }
}

// ── Get recent pages ──
async function getRecentPages(limit = 20, offset = 0) {
    try {
        const db = await getDB();
        const tx = db.transaction('pages', 'readonly');
        const idx = tx.objectStore('pages').index('timestamp');
        return new Promise((resolve) => {
            const results = []; let skipped = 0;
            const req = idx.openCursor(null, 'prev');
            req.onsuccess = (e) => {
                const c = e.target.result;
                if (!c || results.length >= limit) { db.close(); resolve(results); return; }
                if (skipped < offset) { skipped++; c.continue(); return; }
                results.push(c.value); c.continue();
            };
            req.onerror = () => { db.close(); resolve([]); };
        });
    } catch { return []; }
}

// ── Get pages by date ──
async function getPagesByDate(date) {
    try {
        const db = await getDB();
        const tx = db.transaction('pages', 'readonly');
        const idx = tx.objectStore('pages').index('date');
        return new Promise((resolve) => {
            const results = [];
            const req = idx.openCursor(IDBKeyRange.only(date));
            req.onsuccess = (e) => {
                const c = e.target.result;
                if (!c) { db.close(); resolve(results); return; }
                results.push(c.value); c.continue();
            };
            req.onerror = () => { db.close(); resolve([]); };
        });
    } catch { return []; }
}

// ── Page count ──
async function getPageCount() {
    try {
        const db = await getDB();
        const tx = db.transaction('pages', 'readonly');
        return new Promise((r) => {
            const req = tx.objectStore('pages').count();
            req.onsuccess = () => { db.close(); r(req.result); };
            req.onerror = () => { db.close(); r(0); };
        });
    } catch { return 0; }
}

// ── Today stats ──
async function getTodayStats() {
    try {
        const today = getLocalDate();
        const pages = await getPagesByDate(today);
        const domains = new Set(); let totalTime = 0;
        for (const p of pages) { domains.add(p.domain); totalTime += (p.timeSpent || 0); }
        return { pagesVisited: pages.length, totalTimeSpent: totalTime, uniqueDomains: domains.size, date: today };
    } catch { return { pagesVisited: 0, totalTimeSpent: 0, uniqueDomains: 0 }; }
}

// ── All-time stats ──
async function getAllTimeStats() {
    try {
        const db = await getDB();
        const tx = db.transaction('pages', 'readonly');
        return new Promise((resolve) => {
            let total = 0, totalTime = 0, earliest = Infinity;
            const domains = new Set();
            const req = tx.objectStore('pages').openCursor();
            req.onsuccess = (e) => {
                const c = e.target.result;
                if (!c) {
                    db.close();
                    resolve({
                        totalPages: total, totalTimeSpent: totalTime, uniqueDomains: domains.size,
                        earliestDate: earliest === Infinity ? null : getLocalDateFromTimestamp(earliest),
                        estimatedSizeMB: ((total * 1.5) / 1024).toFixed(1)
                    });
                    return;
                }
                total++; totalTime += (c.value.timeSpent || 0); domains.add(c.value.domain);
                if (c.value.timestamp < earliest) earliest = c.value.timestamp;
                c.continue();
            };
            req.onerror = () => { db.close(); resolve({ totalPages: 0, totalTimeSpent: 0, uniqueDomains: 0 }); };
        });
    } catch { return { totalPages: 0, totalTimeSpent: 0, uniqueDomains: 0 }; }
}

// ── Delete page ──
async function deletePage(id) {
    try {
        const db = await getDB();
        const tx = db.transaction('pages', 'readwrite');
        tx.objectStore('pages').delete(id);
        return new Promise((r) => { tx.oncomplete = () => { db.close(); r(true); }; tx.onerror = () => { db.close(); r(false); }; });
    } catch { return false; }
}

// ── Delete old pages ──
async function deleteOldPages(days = 90) {
    try {
        const db = await getDB();
        const cutoff = Date.now() - days * 86400000;
        const tx = db.transaction('pages', 'readwrite');
        const idx = tx.objectStore('pages').index('timestamp');
        return new Promise((resolve) => {
            let del = 0;
            const req = idx.openCursor(IDBKeyRange.upperBound(cutoff));
            req.onsuccess = (e) => { const c = e.target.result; if (!c) { db.close(); resolve(del); return; } c.delete(); del++; c.continue(); };
            req.onerror = () => { db.close(); resolve(del); };
        });
    } catch { return 0; }
}

// ── Clear all data ──
async function clearAllData() {
    try {
        const db = await getDB();
        const names = [...db.objectStoreNames];
        const tx = db.transaction(names, 'readwrite');
        for (const n of names) tx.objectStore(n).clear();
        return new Promise((r) => { tx.oncomplete = () => { db.close(); r(true); }; tx.onerror = () => { db.close(); r(false); }; });
    } catch { return false; }
}

// ── Export ──
async function exportData() {
    try {
        const db = await getDB();
        const tx = db.transaction('pages', 'readonly');
        return new Promise((r) => { const req = tx.objectStore('pages').getAll(); req.onsuccess = () => { db.close(); r(req.result); }; req.onerror = () => { db.close(); r([]); }; });
    } catch { return []; }
}

// ── DB size ──
async function getDatabaseSize() {
    try {
        const all = await exportData();
        const bytes = new Blob([JSON.stringify(all)]).size;
        if (bytes < 1024) return bytes + ' B';
        if (bytes < 1048576) return (bytes / 1024).toFixed(1) + ' KB';
        return (bytes / 1048576).toFixed(1) + ' MB';
    } catch { return '0 B'; }
}

// ── Top domains ──
async function getTopDomains(days = 7, limit = 10) {
    try {
        const db = await getDB();
        const cutoff = Date.now() - days * 86400000;
        const tx = db.transaction('pages', 'readonly');
        const idx = tx.objectStore('pages').index('timestamp');
        return new Promise((resolve) => {
            const counts = {};
            const req = idx.openCursor(IDBKeyRange.lowerBound(cutoff));
            req.onsuccess = (e) => {
                const c = e.target.result;
                if (!c) { db.close(); resolve(Object.entries(counts).map(([d, n]) => ({ domain: d, count: n })).sort((a, b) => b.count - a.count).slice(0, limit)); return; }
                counts[c.value.domain] = (counts[c.value.domain] || 0) + 1; c.continue();
            };
            req.onerror = () => { db.close(); resolve([]); };
        });
    } catch { return []; }
}

// ── Page by ID ──
async function getPageById(id) {
    try {
        const db = await getDB();
        const tx = db.transaction('pages', 'readonly');
        return new Promise((r) => { const req = tx.objectStore('pages').get(id); req.onsuccess = () => { db.close(); r(req.result || null); }; req.onerror = () => { db.close(); r(null); }; });
    } catch { return null; }
}

// ══════════════════════════════════════════════════════
// SECTION 2: SETTINGS (IndexedDB)
// ══════════════════════════════════════════════════════

async function saveSetting(key, value) {
    try {
        const db = await getDB();
        const tx = db.transaction('settings', 'readwrite');
        tx.objectStore('settings').put({ key, value });
        return new Promise((r) => { tx.oncomplete = () => { db.close(); r(true); }; tx.onerror = () => { db.close(); r(false); }; });
    } catch { return false; }
}

async function getSetting(key) {
    try {
        const db = await getDB();
        const tx = db.transaction('settings', 'readonly');
        return new Promise((r) => { const req = tx.objectStore('settings').get(key); req.onsuccess = () => { db.close(); r(req.result ? req.result.value : null); }; req.onerror = () => { db.close(); r(null); }; });
    } catch { return null; }
}

async function getAllSettings() {
    try {
        const db = await getDB();
        const tx = db.transaction('settings', 'readonly');
        return new Promise((r) => {
            const req = tx.objectStore('settings').getAll();
            req.onsuccess = () => { db.close(); const s = {}; for (const i of req.result) s[i.key] = i.value; r(s); };
            req.onerror = () => { db.close(); r({}); };
        });
    } catch { return {}; }
}

// ══════════════════════════════════════════════════════
// SECTION 3: DIGEST CACHE (IndexedDB)
// ══════════════════════════════════════════════════════

async function saveDigestCache(date, data) {
    try {
        const db = await getDB();
        const tx = db.transaction('digestCache', 'readwrite');
        tx.objectStore('digestCache').put({ date, data, cachedAt: Date.now() });
        return new Promise((r) => { tx.oncomplete = () => { db.close(); r(true); }; tx.onerror = () => { db.close(); r(false); }; });
    } catch { return false; }
}

async function getDigestCache(date) {
    try {
        const db = await getDB();
        const tx = db.transaction('digestCache', 'readonly');
        return new Promise((r) => { const req = tx.objectStore('digestCache').get(date); req.onsuccess = () => { db.close(); r(req.result ? req.result.data : null); }; req.onerror = () => { db.close(); r(null); }; });
    } catch { return null; }
}

// ══════════════════════════════════════════════════════
// SECTION 4: COST GUARD
// ══════════════════════════════════════════════════════

function todayCostKey() { return 'bm_daily_' + getLocalDate(); }

async function canUseAI() {
    try { const k = todayCostKey(); const r = await chrome.storage.local.get(k); return (r[k] || 0) < DAILY_AI_LIMIT; } catch { return false; }
}
async function recordAICall() {
    try { const k = todayCostKey(); const r = await chrome.storage.local.get(k); const u = (r[k] || 0) + 1; await chrome.storage.local.set({ [k]: u }); return u; } catch { return -1; }
}
async function getUsage() {
    try { const k = todayCostKey(); const r = await chrome.storage.local.get(k); const u = r[k] || 0; return { used: u, limit: DAILY_AI_LIMIT, remaining: Math.max(0, DAILY_AI_LIMIT - u), percentage: Math.round((u / DAILY_AI_LIMIT) * 100) }; }
    catch { return { used: 0, limit: DAILY_AI_LIMIT, remaining: DAILY_AI_LIMIT, percentage: 0 }; }
}

// ══════════════════════════════════════════════════════
// SECTION 5: URL HELPERS
// ══════════════════════════════════════════════════════

function shouldSkipUrl(url) {
    if (!url || typeof url !== 'string') return true;
    for (const p of SKIP_PREFIXES) { if (url.startsWith(p)) return true; }
    try {
        const h = new URL(url).hostname;
        for (const d of SKIP_DOMAINS) { if (h === d || h.endsWith('.' + d)) return true; }
    } catch { return true; }
    return false;
}

async function isBlocked(url) {
    try {
        const bl = await getSetting('blocklist');
        if (!bl || !Array.isArray(bl) || bl.length === 0) return false;
        const h = new URL(url).hostname;
        return bl.some(d => h === d || h.endsWith('.' + d));
    } catch { return false; }
}

async function getMinTime() {
    try {
        const v = await getSetting('minTime');
        return (v && typeof v === 'number' && v >= 1) ? v : DEFAULT_MIN_TIME;
    } catch { return DEFAULT_MIN_TIME; }
}

async function isPaused() {
    try { return !!(await getSetting('paused')); } catch { return false; }
}

// ══════════════════════════════════════════════════════
// SECTION 6: TAB TRACKING STATE (chrome.storage.session)
// Key: "tabVisits" → { "tabId": { url, startTime, saved } }
// ══════════════════════════════════════════════════════

async function getTabVisits() {
    try {
        const data = await chrome.storage.session.get('tabVisits');
        return data.tabVisits || {};
    } catch { return {}; }
}

async function setTabVisits(visits) {
    try { await chrome.storage.session.set({ tabVisits: visits }); }
    catch (e) { console.error('[BrowseMind] setTabVisits error:', e.message); }
}

async function trackTab(tabId, url) {
    try {
        const visits = await getTabVisits();
        visits[String(tabId)] = { url, startTime: Date.now(), saved: false };
        await setTabVisits(visits);
        console.log('[BrowseMind] Tracking tab', tabId, ':', url);
    } catch (e) { console.error('[BrowseMind] trackTab error:', e.message); }
}

async function markTabSaved(tabId) {
    try {
        const visits = await getTabVisits();
        if (visits[String(tabId)]) { visits[String(tabId)].saved = true; await setTabVisits(visits); }
    } catch { }
}

async function removeTabVisit(tabId) {
    try {
        const visits = await getTabVisits();
        delete visits[String(tabId)];
        await setTabVisits(visits);
    } catch { }
}

async function getTabInfo(tabId) {
    try {
        const visits = await getTabVisits();
        return visits[String(tabId)] || null;
    } catch { return null; }
}

// ══════════════════════════════════════════════════════
// SECTION 7: CONTENT EXTRACTION (runs in page context)
// ══════════════════════════════════════════════════════

function extractPageContent() {
    try {
        const article = document.querySelector('article') ||
            document.querySelector('[role="main"]') || document.querySelector('main') ||
            document.querySelector('.content, .post, .article, #content, #main, .entry-content, .post-content') ||
            document.body;
        const raw = (article ? article.innerText : document.body.innerText) || '';
        const contentPreview = raw.replace(/\s+/g, ' ').trim().substring(0, 500);
        const headings = Array.from(document.querySelectorAll('h1, h2, h3')).slice(0, 10)
            .map(h => h.textContent.trim()).filter(h => h.length > 0 && h.length < 200)
            .join(', ').substring(0, 300);
        const description = document.querySelector('meta[name="description"]')?.content ||
            document.querySelector('meta[property="og:description"]')?.content ||
            contentPreview.substring(0, 160) || '';
        const favicon = document.querySelector('link[rel="icon"]')?.href ||
            document.querySelector('link[rel="shortcut icon"]')?.href ||
            document.querySelector('link[rel="apple-touch-icon"]')?.href ||
            'https://' + window.location.hostname + '/favicon.ico';
        const ogImage = document.querySelector('meta[property="og:image"]')?.content || '';
        const wordCount = raw.split(/\s+/).filter(w => w.length > 0).length;
        if (wordCount < 5 && !document.title) return null;
        return {
            title: document.title || window.location.hostname, url: window.location.href,
            domain: window.location.hostname, description, headings, contentPreview,
            favicon, ogImage, language: document.documentElement.lang || 'en', wordCount
        };
    } catch { return null; }
}

// ══════════════════════════════════════════════════════
// SECTION 8: EXTRACT AND SAVE FROM A TAB
// ══════════════════════════════════════════════════════

async function extractAndSaveTab(tabId, url, timeSpent) {
    try {
        if (shouldSkipUrl(url)) return;
        if (await isBlocked(url)) return;
        if (await isPaused()) return;

        let pageData = null;

        // Try rich extraction via script injection
        try {
            const results = await chrome.scripting.executeScript({
                target: { tabId }, func: extractPageContent
            });
            if (results && results[0] && results[0].result) pageData = results[0].result;
        } catch (e) {
            console.log('[BrowseMind] Can\'t inject tab', tabId, ':', e.message);
        }

        // Fallback: build basic record from tab info or URL
        if (!pageData) {
            let title = url, domain = '';
            try { domain = new URL(url).hostname; } catch { }
            try { const tab = await chrome.tabs.get(tabId); title = tab.title || domain || url; }
            catch { title = domain || url; }
            pageData = {
                title, url, domain, description: '', headings: '',
                contentPreview: title, favicon: domain ? 'https://' + domain + '/favicon.ico' : '',
                ogImage: '', language: 'en', wordCount: 0
            };
        }

        if (!pageData.url) return;
        if (!pageData.title) pageData.title = pageData.domain || 'Untitled';
        pageData.timeSpent = timeSpent;

        const result = await savePage(pageData);
        if (result === 'saved' || result === 'updated') await updateBadge();
    } catch (err) {
        console.error('[BrowseMind] extractAndSaveTab error:', err.message);
    }
}

// ══════════════════════════════════════════════════════
// SECTION 9: METHOD 1 — SAVE ON EXIT
// Save the page the user is leaving (if time >= minTime)
// ══════════════════════════════════════════════════════

async function saveTabIfQualified(tabId) {
    try {
        const info = await getTabInfo(tabId);
        if (!info || !info.url) return;
        if (info.saved) return; // Already captured by alarm or sweep
        if (shouldSkipUrl(info.url)) return;

        const timeSpent = Math.round((Date.now() - info.startTime) / 1000);
        const minTime = await getMinTime();

        if (timeSpent >= minTime) {
            console.log('[BrowseMind] Exit save: tab', tabId, '|', info.url, '(' + timeSpent + 's)');
            await extractAndSaveTab(tabId, info.url, timeSpent);
            await markTabSaved(tabId);
        } else {
            console.log('[BrowseMind] Too short on exit:', timeSpent + 's for', info.url);
        }
    } catch (err) {
        console.error('[BrowseMind] saveTabIfQualified error:', err.message);
    }
}

// EVENT: Page navigation (URL changed in same tab)
chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
    try {
        if (changeInfo.status !== 'complete') return;
        if (!tab.url) return;

        const oldInfo = await getTabInfo(tabId);

        // URL changed in this tab → save the OLD page, track the NEW one
        if (oldInfo && oldInfo.url !== tab.url) {
            console.log('[BrowseMind] Navigation in tab', tabId, ':', oldInfo.url, '→', tab.url);
            await saveTabIfQualified(tabId);
        }

        // Start tracking new URL (or first visit to this tab)
        if (!shouldSkipUrl(tab.url)) {
            await trackTab(tabId, tab.url);
            // METHOD 2: set alarm to fire 30s after page load
            chrome.alarms.create('bm_tab_' + tabId, { delayInMinutes: 0.5 });
        }
    } catch (err) {
        console.error('[BrowseMind] onUpdated error:', err.message);
    }
});

// EVENT: Tab switched
chrome.tabs.onActivated.addListener(async (activeInfo) => {
    try {
        // Save ALL unsaved tabs that aren't the newly active one
        const visits = await getTabVisits();
        for (const [tid, info] of Object.entries(visits)) {
            const tidNum = parseInt(tid);
            if (tidNum !== activeInfo.tabId && !info.saved) {
                await saveTabIfQualified(tidNum);
            }
        }

        // Track the newly active tab
        const tab = await chrome.tabs.get(activeInfo.tabId);
        if (tab && tab.url && !shouldSkipUrl(tab.url)) {
            const existing = await getTabInfo(activeInfo.tabId);
            if (!existing || existing.url !== tab.url) {
                await trackTab(activeInfo.tabId, tab.url);
            }
            // Reset/set alarm for active tab
            chrome.alarms.create('bm_tab_' + activeInfo.tabId, { delayInMinutes: 0.5 });
        }
        console.log('[BrowseMind] Tab switched to:', tab?.url || '(unknown)');
    } catch (err) {
        console.error('[BrowseMind] onActivated error:', err.message);
    }
});

// EVENT: Tab closed
chrome.tabs.onRemoved.addListener(async (tabId) => {
    try {
        console.log('[BrowseMind] Tab closed:', tabId);
        await saveTabIfQualified(tabId);
        await removeTabVisit(tabId);
        chrome.alarms.clear('bm_tab_' + tabId);
    } catch (err) {
        console.error('[BrowseMind] onRemoved error:', err.message);
    }
});

// EVENT: Window focus changed
chrome.windows.onFocusChanged.addListener(async (windowId) => {
    try {
        if (windowId === chrome.windows.WINDOW_ID_NONE) return;
        const [activeTab] = await chrome.tabs.query({ active: true, windowId });
        if (activeTab && activeTab.url && !shouldSkipUrl(activeTab.url)) {
            const existing = await getTabInfo(activeTab.id);
            if (!existing || existing.url !== activeTab.url) {
                await trackTab(activeTab.id, activeTab.url);
                chrome.alarms.create('bm_tab_' + activeTab.id, { delayInMinutes: 0.5 });
            }
        }
    } catch { }
});

// ══════════════════════════════════════════════════════
// SECTION 10: METHOD 2 — ALARM-BASED CAPTURE
// 30s after page load, save if still on that page
// ══════════════════════════════════════════════════════

chrome.alarms.onAlarm.addListener(async (alarm) => {
    try {
        // Individual tab alarm
        if (alarm.name.startsWith('bm_tab_')) {
            const tabId = parseInt(alarm.name.replace('bm_tab_', ''));
            const info = await getTabInfo(tabId);
            if (!info || info.saved) return;

            const timeSpent = Math.round((Date.now() - info.startTime) / 1000);
            const minTime = await getMinTime();

            if (timeSpent >= minTime) {
                console.log('[BrowseMind] Alarm save: tab', tabId, '|', info.url, '(' + timeSpent + 's)');
                await extractAndSaveTab(tabId, info.url, timeSpent);
                await markTabSaved(tabId);
            }
            return;
        }

        // Periodic sweep alarm
        if (alarm.name === 'bm_sweep') {
            await periodicSweep();
            return;
        }
    } catch (err) {
        console.error('[BrowseMind] Alarm handler error:', err.message);
    }
});

// ══════════════════════════════════════════════════════
// SECTION 11: METHOD 3 — PERIODIC SWEEP (every 2 min)
// Safety net: checks ALL open tabs for unsaved pages
// ══════════════════════════════════════════════════════

async function periodicSweep() {
    try {
        if (await isPaused()) return;

        const allTabs = await chrome.tabs.query({});
        const visits = await getTabVisits();
        const minTime = await getMinTime();
        let savedCount = 0;

        for (const tab of allTabs) {
            if (!tab.url || shouldSkipUrl(tab.url)) continue;

            const key = String(tab.id);
            const info = visits[key];

            if (info && info.saved) continue; // Already saved

            if (info && !info.saved) {
                // Tracked but not saved — check time
                const timeSpent = Math.round((Date.now() - info.startTime) / 1000);
                if (timeSpent >= minTime) {
                    console.log('[BrowseMind] Sweep save: tab', tab.id, '|', info.url, '(' + timeSpent + 's)');
                    await extractAndSaveTab(tab.id, tab.url, timeSpent);
                    await markTabSaved(tab.id);
                    savedCount++;
                }
            } else {
                // Not tracked at all — start tracking now + set alarm
                await trackTab(tab.id, tab.url);
                chrome.alarms.create('bm_tab_' + tab.id, { delayInMinutes: 0.5 });
            }
        }

        // Cleanup: remove visits for closed tabs
        const openIds = new Set(allTabs.map(t => String(t.id)));
        let cleaned = false;
        for (const tid of Object.keys(visits)) {
            if (!openIds.has(tid)) { delete visits[tid]; cleaned = true; }
        }
        if (cleaned) await setTabVisits(visits);

        if (savedCount > 0) {
            console.log('[BrowseMind] Sweep saved', savedCount, 'pages');
            await updateBadge();
        }
    } catch (err) {
        console.error('[BrowseMind] Sweep error:', err.message);
    }
}

// ══════════════════════════════════════════════════════
// SECTION 12: LOCAL SEARCH
// ══════════════════════════════════════════════════════

async function searchLocal(query, limit = 15) {
    try {
        const keywords = query.toLowerCase().trim().replace(/\s+/g, ' ').split(' ')
            .filter(k => k.length > 1 && !STOP_WORDS.has(k));
        if (keywords.length === 0) return [];
        const db = await getDB();
        const tx = db.transaction('pages', 'readonly');
        return new Promise((resolve) => {
            const scored = [];
            const req = tx.objectStore('pages').openCursor();
            req.onsuccess = (e) => {
                const c = e.target.result;
                if (!c) {
                    db.close();
                    scored.sort((a, b) => b.score - a.score || b.timestamp - a.timestamp);
                    resolve(scored.slice(0, limit));
                    return;
                }
                const r = c.value; let score = 0;
                const t = (r.title || '').toLowerCase(), d = (r.domain || '').toLowerCase(),
                    h = (r.headings || '').toLowerCase(), desc = (r.description || '').toLowerCase(),
                    cp = (r.contentPreview || '').toLowerCase();
                for (const kw of keywords) {
                    if (t.includes(kw)) score += 10; if (d.includes(kw)) score += 8;
                    if (h.includes(kw)) score += 6; if (desc.includes(kw)) score += 4;
                    if (cp.includes(kw)) score += 2;
                }
                if (score > 0) {
                    const days = (Date.now() - r.timestamp) / 86400000;
                    if (days < 1) score += 5; else if (days < 3) score += 3; else if (days < 7) score += 1;
                    if (r.timeSpent > 120) score += 3; else if (r.timeSpent > 60) score += 1;
                    scored.push({ ...r, score });
                }
                c.continue();
            };
            req.onerror = () => { db.close(); resolve([]); };
        });
    } catch { return []; }
}

// ══════════════════════════════════════════════════════
// SECTION 13: AI SEARCH
// ══════════════════════════════════════════════════════

function formatPagesForAI(pages) {
    return pages.map(p => {
        const d = p.date || getLocalDateFromTimestamp(p.timestamp);
        return `${p.id} | ${(p.title || 'Untitled').substring(0, 60)} | ${p.domain} | ${d} | ${(p.description || p.contentPreview || '').substring(0, 80)}`;
    }).join('\n');
}

async function searchAI(query, contextPages) {
    try {
        if (!query || query.length < 3 || query.length > 500) return { error: 'Query must be 3-500 characters' };
        let toSend = contextPages;
        if (formatPagesForAI(toSend).length > 15000) toSend = contextPages.slice(0, 30);
        const response = await fetch(PROXY_URL + '/search', {
            method: 'POST', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'search', query, pages: formatPagesForAI(toSend) })
        });
        if (!response.ok) return response.status === 429 ? { error: 'AI busy. Try again.' } : { error: 'AI unavailable.' };
        return await response.json();
    } catch (err) { return { error: 'AI unavailable.' }; }
}

// ══════════════════════════════════════════════════════
// SECTION 14: DIGEST
// ══════════════════════════════════════════════════════

function buildDigestData(pages) {
    if (!pages || pages.length === 0) return null;
    const dc = {}; let tt = 0;
    for (const p of pages) { const d = p.domain || 'unknown'; dc[d] = (dc[d] || 0) + 1; tt += (p.timeSpent || 0); }
    const sorted = Object.entries(dc).sort((a, b) => b[1] - a[1]);
    const top = sorted.slice(0, 5).map(([d, c]) => `${d} (${c})`).join(', ');
    return `Pages visited: ${pages.length}\nDomains: ${top}\nTotal reading time: ${(tt / 3600).toFixed(1)} hours\nUnique domains: ${Object.keys(dc).length}\nPage titles:\n${pages.map(p => p.title || 'Untitled').join('\n')}`;
}

async function generateDigestFromAI(pages, date) {
    try {
        if (!pages || pages.length < 5) return { error: 'Not enough data for a digest.' };
        let data = buildDigestData(pages);
        if (!data) return { error: 'Could not build digest data.' };
        if (data.length > 10000) data = buildDigestData(pages.slice(0, 50));
        const resp = await fetch(PROXY_URL + '/digest', {
            method: 'POST', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'digest', data })
        });
        if (!resp.ok) return resp.status === 429 ? { error: 'AI busy.' } : { error: "Couldn't generate digest." };
        return await resp.json();
    } catch { return { error: "Couldn't generate digest." }; }
}

// ══════════════════════════════════════════════════════
// SECTION 15: BADGE
// ══════════════════════════════════════════════════════

async function updateBadge() {
    try {
        if (await isPaused()) {
            await chrome.action.setBadgeText({ text: '⏸' });
            await chrome.action.setBadgeBackgroundColor({ color: '#72757e' });
            return;
        }
        const pages = await getPagesByDate(getLocalDate());
        const count = pages.length;
        if (count > 0) {
            await chrome.action.setBadgeText({ text: String(count) });
            await chrome.action.setBadgeBackgroundColor({ color: '#6c5ce7' });
        } else {
            await chrome.action.setBadgeText({ text: '' });
        }
        console.log('[BrowseMind] Badge:', count, 'pages today');
    } catch { }
}

// ══════════════════════════════════════════════════════
// SECTION 16: MESSAGE HANDLER (popup/fullpage/settings)
// ══════════════════════════════════════════════════════

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    handleMessage(message).then(r => sendResponse(r)).catch(err => {
        console.error('[BrowseMind] Message error:', err.message);
        sendResponse({ error: err.message });
    });
    return true; // CRITICAL: keeps channel open for async response
});

async function handleMessage(msg) {
    const { action } = msg;
    switch (action) {

        // ── Popup opened → save current page immediately ──
        case 'popupOpened': {
            try {
                const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
                if (tab && tab.url && !shouldSkipUrl(tab.url)) {
                    const info = await getTabInfo(tab.id);
                    if (info && !info.saved) {
                        const t = Math.round((Date.now() - info.startTime) / 1000);
                        if (t >= 5) { // Lower threshold for popup trigger
                            console.log('[BrowseMind] Popup opened — saving current page (' + t + 's)');
                            await extractAndSaveTab(tab.id, tab.url, t);
                            await markTabSaved(tab.id);
                        }
                    }
                }
            } catch { }
            return { status: 'ok' };
        }

        // ── Pages ──
        case 'getRecentPages': return { pages: await getRecentPages(msg.limit || 20, msg.offset || 0) };
        case 'getPagesByDate': return { pages: await getPagesByDate(msg.date) };
        case 'getPageCount': return { count: await getPageCount() };
        case 'deletePage': { const ok = await deletePage(msg.id); if (ok) await updateBadge(); return { success: ok }; }

        // ── Search ──
        case 'searchLocal': return { results: await searchLocal(msg.query, msg.limit || 15) };
        case 'searchAI': {
            if (!(await canUseAI())) { const u = await getUsage(); return { error: `AI limit reached (${u.used}/${u.limit}).` }; }
            let ctx = (msg.localResults && msg.localResults.length > 0) ? msg.localResults : await getRecentPages(50);
            if (ctx.length === 0) return { error: 'No browsing memories yet!' };
            const aiR = await searchAI(msg.query, ctx);
            await recordAICall();
            if (aiR.results && Array.isArray(aiR.results)) {
                const full = [];
                for (const r of aiR.results) { const p = await getPageById(r.id); if (p) full.push({ ...p, relevance: r.relevance, reason: r.reason, isAI: true }); }
                return { results: full, interpretation: aiR.interpretation, usage: await getUsage() };
            }
            return aiR;
        }
        case 'searchWithFilters': {
            let results = await searchLocal(msg.query, 100);
            if (msg.domain) results = results.filter(r => r.domain === msg.domain);
            if (msg.startDate) { const s = new Date(msg.startDate).getTime(); results = results.filter(r => r.timestamp >= s); }
            if (msg.endDate) { const e = new Date(msg.endDate + 'T23:59:59').getTime(); results = results.filter(r => r.timestamp <= e); }
            if (msg.sortBy === 'date') results.sort((a, b) => b.timestamp - a.timestamp);
            else if (msg.sortBy === 'timeSpent') results.sort((a, b) => (b.timeSpent || 0) - (a.timeSpent || 0));
            return { results: results.slice(0, msg.limit || 30) };
        }

        // ── Digest ──
        case 'generateDigest': {
            const date = msg.date || getLocalDate();
            const cached = await getDigestCache(date);
            if (cached) return { digest: cached, fromCache: true };
            if (!(await canUseAI())) return { error: 'AI limit reached today.' };
            const pages = await getPagesByDate(date);
            const result = await generateDigestFromAI(pages, date);
            if (result.error) return result;
            await recordAICall();
            await saveDigestCache(date, result);
            return { digest: result, fromCache: false };
        }

        // ── Stats ──
        case 'getTodayStats': return await getTodayStats();
        case 'getAllTimeStats': return await getAllTimeStats();
        case 'getUsage': return await getUsage();
        case 'getTopDomains': return { domains: await getTopDomains(msg.days || 7, msg.limit || 10) };

        // ── Data management ──
        case 'clearAllData': { await clearAllData(); await updateBadge(); return { success: true }; }
        case 'exportData': return { data: await exportData() };
        case 'getDatabaseSize': return { size: await getDatabaseSize() };
        case 'cleanupOldPages': return { deleted: await deleteOldPages(msg.days || 90) };

        // ── Settings ──
        case 'getSettings': return { settings: await getAllSettings() };
        case 'getSetting': return { value: await getSetting(msg.key) };
        case 'saveSetting': {
            await saveSetting(msg.key, msg.value);
            if (msg.key === 'paused') await updateBadge();
            return { success: true };
        }

        default: return { error: 'Unknown action: ' + action };
    }
}

// ══════════════════════════════════════════════════════
// SECTION 17: INSTALL / STARTUP
// ══════════════════════════════════════════════════════

chrome.runtime.onInstalled.addListener(async (details) => {
    console.log('[BrowseMind] Installed/Updated:', details.reason);
    try {
        const db = await getDB(); db.close();
        console.log('[BrowseMind] Database ready');

        // Initialize default settings
        const defaults = { minTime: 10, retentionDays: 90, autoCleanup: true, aiSearch: true, aiDigest: true, paused: false, blocklist: [] };
        for (const [k, v] of Object.entries(defaults)) { if ((await getSetting(k)) === null) await saveSetting(k, v); }

        await chrome.storage.session.remove('tabVisits');
        await updateBadge();

        // Start sweep alarm
        chrome.alarms.create('bm_sweep', { delayInMinutes: 1, periodInMinutes: 2 });

        // Track current active tab
        try {
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
            if (tab && tab.url && !shouldSkipUrl(tab.url)) {
                await trackTab(tab.id, tab.url);
                chrome.alarms.create('bm_tab_' + tab.id, { delayInMinutes: 0.5 });
            }
        } catch { }
        console.log('[BrowseMind] ✅ Initialization complete');
    } catch (err) { console.error('[BrowseMind] Install error:', err); }
});

chrome.runtime.onStartup.addListener(async () => {
    console.log('[BrowseMind] Browser started');
    try {
        await chrome.storage.session.remove('tabVisits');

        // Auto-cleanup
        const autoCleanup = await getSetting('autoCleanup');
        if (autoCleanup !== false) {
            const days = (await getSetting('retentionDays')) || 90;
            const del = await deleteOldPages(days);
            if (del > 0) console.log('[BrowseMind] Cleaned', del, 'old pages');
        }

        await updateBadge();

        // Start sweep alarm
        chrome.alarms.create('bm_sweep', { delayInMinutes: 1, periodInMinutes: 2 });

        // Track current active tab
        try {
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
            if (tab && tab.url && !shouldSkipUrl(tab.url)) {
                await trackTab(tab.id, tab.url);
                chrome.alarms.create('bm_tab_' + tab.id, { delayInMinutes: 0.5 });
                console.log('[BrowseMind] Started tracking:', tab.url);
            }
        } catch { }
    } catch (err) { console.error('[BrowseMind] Startup error:', err); }
});

// ── Idle detection (informational) ──
chrome.idle.setDetectionInterval(60);
chrome.idle.onStateChanged.addListener((state) => {
    console.log('[BrowseMind] Idle state:', state);
});

console.log('[BrowseMind] Service worker loaded — three-pronged capture active');
