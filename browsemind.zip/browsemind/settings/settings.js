/**
 * BrowseMind — Settings Controller
 * Manages all user preferences and data management.
 */

document.addEventListener('DOMContentLoaded', init);

function sendMessage(msg) {
    return new Promise(resolve => {
        try {
            chrome.runtime.sendMessage(msg, r => {
                if (chrome.runtime.lastError) {
                    console.warn('[BrowseMind Settings] sendMessage error:', chrome.runtime.lastError.message);
                    resolve({});
                    return;
                }
                resolve(r || {});
            });
        } catch (err) {
            console.warn('[BrowseMind Settings] sendMessage exception:', err);
            resolve({});
        }
    });
}

async function init() {
    await loadSettings();
    await loadDataInfo();
    setupListeners();
    setupBlocklist();
    setupDataActions();
}

// ── Load current settings ──
async function loadSettings() {
    const resp = await sendMessage({ action: 'getSettings' });
    const s = resp.settings || {};

    // Memory
    document.getElementById('settingMinTime').value = s.minTime || 30;
    document.getElementById('settingRetention').value = s.retentionDays || 90;
    document.getElementById('settingAutoCleanup').checked = s.autoCleanup !== false;

    // Privacy
    document.getElementById('settingPaused').checked = !!s.paused;

    // AI
    document.getElementById('settingAISearch').checked = s.aiSearch !== false;
    document.getElementById('settingAIDigest').checked = s.aiDigest !== false;

    // AI usage
    const usage = await sendMessage({ action: 'getUsage' });
    document.getElementById('aiUsageText').textContent = `${usage.used || 0} / ${usage.limit || 20} AI calls used`;
    document.getElementById('aiUsageBar').style.width = `${usage.percentage || 0}%`;

    // Blocklist
    renderBlocklist(s.blocklist || []);
}

// ── Load data info ──
async function loadDataInfo() {
    const stats = await sendMessage({ action: 'getAllTimeStats' });
    const size = await sendMessage({ action: 'getDatabaseSize' });

    document.getElementById('storageInfo').textContent =
        `${size.size || '0 B'} (${stats.totalPages || 0} pages)`;
    document.getElementById('oldestMemory').textContent =
        stats.earliestDate || 'No memories yet';
}

// ── Setting change listeners ──
function setupListeners() {
    // Auto-save on change
    const saveSetting = async (key, value) => {
        await sendMessage({ action: 'saveSetting', key, value });
        flashSave();
    };

    document.getElementById('settingMinTime').addEventListener('change', function () {
        saveSetting('minTime', parseInt(this.value));
    });

    document.getElementById('settingRetention').addEventListener('change', function () {
        saveSetting('retentionDays', parseInt(this.value));
    });

    document.getElementById('settingAutoCleanup').addEventListener('change', function () {
        saveSetting('autoCleanup', this.checked);
    });

    document.getElementById('settingPaused').addEventListener('change', function () {
        saveSetting('paused', this.checked);
    });

    document.getElementById('settingAISearch').addEventListener('change', function () {
        saveSetting('aiSearch', this.checked);
    });

    document.getElementById('settingAIDigest').addEventListener('change', function () {
        saveSetting('aiDigest', this.checked);
    });
}

// ── Blocklist ──
function setupBlocklist() {
    document.getElementById('blocklistAdd').addEventListener('click', addBlocklistDomain);
    document.getElementById('blocklistInput').addEventListener('keydown', (e) => {
        if (e.key === 'Enter') addBlocklistDomain();
    });
}

async function addBlocklistDomain() {
    const input = document.getElementById('blocklistInput');
    let domain = input.value.trim().toLowerCase();
    if (!domain) return;

    // Clean domain
    domain = domain.replace(/^https?:\/\//, '').replace(/\/.*$/, '').replace(/^www\./, '');
    if (!domain) return;

    const resp = await sendMessage({ action: 'getSetting', key: 'blocklist' });
    const blocklist = resp.value || [];

    if (blocklist.includes(domain)) {
        input.value = '';
        return;
    }

    blocklist.push(domain);
    await sendMessage({ action: 'saveSetting', key: 'blocklist', value: blocklist });
    renderBlocklist(blocklist);
    input.value = '';
    flashSave();
}

async function removeBlocklistDomain(domain) {
    const resp = await sendMessage({ action: 'getSetting', key: 'blocklist' });
    const blocklist = (resp.value || []).filter(d => d !== domain);
    await sendMessage({ action: 'saveSetting', key: 'blocklist', value: blocklist });
    renderBlocklist(blocklist);
    flashSave();
}

function renderBlocklist(domains) {
    const container = document.getElementById('blocklistTags');
    container.innerHTML = '';

    domains.forEach(domain => {
        const tag = document.createElement('span');
        tag.className = 'blocklist-tag';
        tag.innerHTML = `${escapeHtml(domain)} <button class="blocklist-tag-remove" title="Remove">✕</button>`;
        tag.querySelector('.blocklist-tag-remove').addEventListener('click', () => removeBlocklistDomain(domain));
        container.appendChild(tag);
    });

    if (domains.length === 0) {
        container.innerHTML = '<span style="font-size:11px;color:var(--text-muted)">No blocked domains</span>';
    }
}

// ── Data Actions ──
function setupDataActions() {
    // Export
    document.getElementById('btnExport').addEventListener('click', async () => {
        const resp = await sendMessage({ action: 'exportData' });
        const data = resp.data || [];
        const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `browsemind-export-${new Date().toISOString().split('T')[0]}.json`;
        a.click();
        URL.revokeObjectURL(url);
    });

    // Cleanup
    document.getElementById('btnCleanup').addEventListener('click', async () => {
        const retentionDays = parseInt(document.getElementById('settingRetention').value) || 90;
        const resp = await sendMessage({ action: 'cleanupOldPages', days: retentionDays });
        alert(`Cleaned up ${resp.deleted || 0} old entries.`);
        await loadDataInfo();
    });

    // Clear all
    document.getElementById('btnClearAll').addEventListener('click', () => {
        document.getElementById('clearModal').style.display = 'flex';
    });

    document.getElementById('clearCancel').addEventListener('click', () => {
        document.getElementById('clearModal').style.display = 'none';
    });

    document.getElementById('clearConfirm').addEventListener('click', async () => {
        await sendMessage({ action: 'clearAllData' });
        document.getElementById('clearModal').style.display = 'none';
        await loadDataInfo();
        alert('All browsing memories have been deleted.');
    });
}

// ── Helpers ──
function flashSave() {
    // Brief visual confirmation
    document.body.style.transition = 'background 0.3s';
    document.body.style.background = '#0f1117';
    setTimeout(() => { document.body.style.background = ''; }, 300);
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}
